// skylineOS 2 — UserSelectOverlay.qml (Switch 2 "Select a user." / "Who is playing?" bottom sheet)
import QtQuick 2.12
import QtGraphicalEffects 1.0

FocusScope {
    id: overlayRoot
    anchors.fill: parent
    z: 300
    visible: bgDim.opacity > 0.01

    property bool isOpen: false
    property string headerTitle: "Select a user."
    property var pendingCallback: null
    property bool creatingUser: false
    property string newCharId: "mario"
    property string newUserName: ""
    property int selectedIndex: 0

    property var defaultUsersJson: '[{"id":"u1","name":"Mario","characterId":"mario","friendCode":"SW-4821-7094-1122"},{"id":"u2","name":"Luigi","characterId":"luigi","friendCode":"SW-3109-6412-8840"},{"id":"u3","name":"Peach","characterId":"peach","friendCode":"SW-7740-1923-5501"}]'
    property var charOptions: ["mario", "luigi", "peach", "yoshi", "dk", "bowser"]
    property var charLabels: ["Mario", "Luigi", "Peach", "Yoshi", "DK", "Bowser"]

    signal userPicked(var userObj)
    signal closed()

    ListModel { id: usersListModel }

    function loadUsers() {
        usersListModel.clear();
        var raw = api.memory.has("ns2_users_json") ? String(api.memory.get("ns2_users_json")) : defaultUsersJson;
        var parsed = null;
        try { parsed = JSON.parse(raw); } catch (e) { parsed = null; }
        if (!parsed || !parsed.length) {
            try { parsed = JSON.parse(defaultUsersJson); } catch (e2) { parsed = []; }
        }
        var activeId = api.memory.has("ns2_active_user_id") ? String(api.memory.get("ns2_active_user_id")) : "u1";
        var foundIdx = 0;
        for (var i = 0; i < parsed.length; i++) {
            var u = parsed[i];
            if (u && u.id) {
                usersListModel.append({
                    uid: String(u.id),
                    uname: String(u.name || "Player"),
                    uchar: String(u.characterId || "mario"),
                    ufc: String(u.friendCode || "SW-1234-5678-9012"),
                    isCreateTile: false
                });
                if (String(u.id) === activeId) foundIdx = usersListModel.count - 1;
            }
        }
        usersListModel.append({
            uid: "__add__",
            uname: "Create New User",
            uchar: "mario",
            ufc: "",
            isCreateTile: true
        });
        selectedIndex = foundIdx;
    }

    function saveUsersArray(arr) {
        api.memory.set("ns2_users_json", JSON.stringify(arr));
    }

    function open(title, cb) {
        headerTitle = (title && title !== "") ? title : "Select a user.";
        pendingCallback = cb || null;
        creatingUser = false;
        newCharId = "mario";
        newUserName = "";
        loadUsers();
        isOpen = true;
        overlayRoot.forceActiveFocus();
        Qt.callLater(function() { userGrid.forceActiveFocus(); });
    }

    function closeCancelled() {
        isOpen = false;
        creatingUser = false;
        pendingCallback = null;
        backSfx.play();
        closed();
    }

    function activateTile(idx) {
        if (idx < 0 || idx >= usersListModel.count) return;
        var item = usersListModel.get(idx);
        if (item.isCreateTile) {
            selectSfx.play();
            creatingUser = true;
            newUserName = "";
            newCharId = "yoshi";
            Qt.callLater(function() { newNameInput.forceActiveFocus(); });
            return;
        }
        api.memory.set("ns2_active_user_id", item.uid);
        api.memory.set("ns2_active_character", item.uchar);
        api.memory.set("Username", item.uname);
        api.memory.set("Launcher User", item.uname);
        refreshSettings();
        selectSfx.play();
        isOpen = false;
        var pickedObj = { id: item.uid, name: item.uname, characterId: item.uchar, friendCode: item.ufc };
        var cb = pendingCallback;
        pendingCallback = null;
        userPicked(pickedObj);
        if (cb) cb(pickedObj);
    }

    function commitCreateUser() {
        var trimmed = String(newUserName || "").trim();
        if (trimmed === "") {
            for (var c = 0; c < charOptions.length; c++) {
                if (charOptions[c] === newCharId) { trimmed = charLabels[c]; break; }
            }
            if (trimmed === "") trimmed = "Player";
        }
        var raw = api.memory.has("ns2_users_json") ? String(api.memory.get("ns2_users_json")) : defaultUsersJson;
        var arr = [];
        try { arr = JSON.parse(raw); } catch (e) { arr = []; }
        if (!arr || !arr.length) {
            try { arr = JSON.parse(defaultUsersJson); } catch (e2) { arr = []; }
        }
        var nid = "u" + String(Date.now());
        var fc = "SW-" + String(1000 + Math.floor(Math.random() * 8999)) + "-" + String(1000 + Math.floor(Math.random() * 8999)) + "-" + String(1000 + Math.floor(Math.random() * 8999));
        var newObj = { id: nid, name: trimmed, characterId: newCharId, friendCode: fc };
        arr.push(newObj);
        saveUsersArray(arr);
        api.memory.set("ns2_active_user_id", nid);
        api.memory.set("ns2_active_character", newCharId);
        api.memory.set("Username", trimmed);
        api.memory.set("Launcher User", trimmed);
        refreshSettings();
        newUserSfx.play();
        creatingUser = false;
        isOpen = false;
        var cb = pendingCallback;
        pendingCallback = null;
        userPicked(newObj);
        if (cb) cb(newObj);
    }

    property bool isDarkSheet: (settings.appearanceMode === "Dark") || (settings.appearanceMode === "Auto" && settings.darkMode === "Yes")
    property color sheetBg: isDarkSheet ? "#1F2126" : "#EFEFEF"
    property color sheetCard: isDarkSheet ? "#2A2D34" : "#FFFFFF"
    property color sheetText: isDarkSheet ? "#F3F4F6" : "#2C2C2C"
    property color sheetMuted: isDarkSheet ? "#9CA3AF" : "#6B7280"
    property color sheetDivider: isDarkSheet ? "#383B44" : "#CFCFCF"

    Rectangle {
        id: bgDim
        anchors.fill: parent
        color: "#000000"
        opacity: overlayRoot.isOpen ? 0.52 : 0.0
        Behavior on opacity { NumberAnimation { duration: 200 } }
        MouseArea {
            anchors.fill: parent
            enabled: overlayRoot.isOpen
            onClicked: overlayRoot.closeCancelled()
        }
    }

    Rectangle {
        id: sheet
        width: parent.width
        height: Math.round(parent.height * 0.52)
        x: 0
        y: overlayRoot.isOpen ? (parent.height - height) : parent.height
        color: overlayRoot.sheetBg
        Behavior on y { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }

        MouseArea { anchors.fill: parent }

        Rectangle { anchors.top: parent.top; width: parent.width; height: vpx(2); color: theme.accent; opacity: 0.7 }

        Item {
            id: sheetHeader
            anchors { top: parent.top; left: parent.left; right: parent.right; leftMargin: screenmargin; rightMargin: screenmargin }
            height: Math.round(parent.height * 0.22)

            Row {
                anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                spacing: vpx(12)
                Rectangle { width: vpx(5); height: vpx(26); radius: vpx(2); color: theme.accent; anchors.verticalCenter: parent.verticalCenter }
                Text {
                    text: overlayRoot.creatingUser ? tr("Create New User") : tr(overlayRoot.headerTitle)
                    color: overlayRoot.sheetText; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.036); font.bold: true
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
            Text {
                anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                text: tr("Retroid Pocket 5 · Active Profile")
                color: overlayRoot.sheetMuted; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.020)
            }
            Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: overlayRoot.sheetDivider }
        }

        ListView {
            id: userGrid
            visible: !overlayRoot.creatingUser
            anchors {
                top: sheetHeader.bottom; bottom: sheetFooter.top; left: parent.left; right: parent.right
                leftMargin: screenmargin; rightMargin: screenmargin; topMargin: vpx(16); bottomMargin: vpx(10)
            }
            orientation: ListView.Horizontal
            spacing: vpx(18)
            clip: true
            model: usersListModel
            currentIndex: overlayRoot.selectedIndex
            focus: !overlayRoot.creatingUser

            onCurrentIndexChanged: overlayRoot.selectedIndex = currentIndex
            Keys.onLeftPressed: { navSound.play(); decrementCurrentIndex(); }
            Keys.onRightPressed: { navSound.play(); incrementCurrentIndex(); }
            Keys.onPressed: {
                if (api.keys.isAccept(event) && !event.isAutoRepeat) {
                    event.accepted = true;
                    overlayRoot.activateTile(currentIndex);
                } else if (api.keys.isCancel(event) && !event.isAutoRepeat) {
                    event.accepted = true;
                    overlayRoot.closeCancelled();
                }
            }

            delegate: Item {
                id: userTile
                width: Math.round(sheet.height * 0.42)
                height: userGrid.height
                property bool isCur: ListView.isCurrentItem

                Column {
                    anchors.centerIn: parent
                    spacing: vpx(8)
                    Rectangle {
                        id: tileBox
                        width: Math.round(sheet.height * 0.34); height: width; radius: vpx(14)
                        color: overlayRoot.sheetCard
                        border.width: isCur ? vpx(4) : vpx(1)
                        border.color: isCur ? theme.accent : overlayRoot.sheetDivider
                        scale: isCur ? 1.05 : 1.0
                        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutQuad } }
                        anchors.horizontalCenter: parent.horizontalCenter

                        Image {
                            visible: !isCreateTile
                            anchors.fill: parent; anchors.margins: vpx(6)
                            source: "../assets/images/avatars/" + uchar + ".png"
                            fillMode: Image.PreserveAspectCrop; smooth: true; asynchronous: true
                        }
                        Item {
                            visible: isCreateTile; anchors.fill: parent
                            Text {
                                anchors.centerIn: parent; text: "+"
                                color: isCur ? theme.accent : overlayRoot.sheetMuted
                                font.family: titleFont.name; font.pixelSize: Math.round(tileBox.width * 0.48); font.bold: true
                            }
                        }
                    }
                    Text {
                        width: tileBox.width + vpx(14); text: uname
                        color: isCur ? theme.accent : overlayRoot.sheetText
                        font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.023); font.bold: isCur
                        elide: Text.ElideRight; horizontalAlignment: Text.AlignHCenter; anchors.horizontalCenter: parent.horizontalCenter
                    }
                }

                MouseArea {
                    anchors.fill: parent; hoverEnabled: true
                    onEntered: userGrid.currentIndex = index
                    onClicked: { userGrid.currentIndex = index; overlayRoot.activateTile(index); }
                }
            }
        }

        Item {
            id: createForm
            visible: overlayRoot.creatingUser
            anchors {
                top: sheetHeader.bottom; bottom: sheetFooter.top; left: parent.left; right: parent.right
                leftMargin: screenmargin; rightMargin: screenmargin; topMargin: vpx(14); bottomMargin: vpx(10)
            }

            Column {
                anchors.centerIn: parent
                width: Math.min(parent.width, vpx(760))
                spacing: vpx(14)

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: vpx(12)
                    Repeater {
                        model: overlayRoot.charOptions
                        delegate: Rectangle {
                            width: vpx(64); height: vpx(64); radius: vpx(10)
                            color: overlayRoot.sheetCard
                            border.width: overlayRoot.newCharId === modelData ? vpx(4) : vpx(1)
                            border.color: overlayRoot.newCharId === modelData ? theme.accent : overlayRoot.sheetDivider
                            Image { anchors.fill: parent; anchors.margins: vpx(4); source: "../assets/images/avatars/" + modelData + ".png"; fillMode: Image.PreserveAspectCrop; smooth: true }
                            MouseArea { anchors.fill: parent; onClicked: { navSound.play(); overlayRoot.newCharId = modelData; } }
                        }
                    }
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: vpx(12)
                    Rectangle {
                        width: vpx(320); height: vpx(46); radius: vpx(8)
                        color: overlayRoot.sheetCard
                        border.width: vpx(2); border.color: newNameInput.activeFocus ? theme.accent : overlayRoot.sheetDivider
                        TextInput {
                            id: newNameInput
                            anchors.fill: parent; anchors.margins: vpx(10)
                            verticalAlignment: TextInput.AlignVCenter
                            color: overlayRoot.sheetText; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.025)
                            maximumLength: 14
                            onTextChanged: overlayRoot.newUserName = text
                            Keys.onPressed: {
                                if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) { event.accepted = true; overlayRoot.commitCreateUser(); }
                                else if (event.key === Qt.Key_Escape) { event.accepted = true; overlayRoot.creatingUser = false; userGrid.forceActiveFocus(); }
                            }
                        }
                        Text {
                            visible: newNameInput.text === ""
                            anchors.fill: parent; anchors.margins: vpx(10); verticalAlignment: Text.AlignVCenter
                            text: tr("Enter nickname..."); color: overlayRoot.sheetMuted; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.023)
                        }
                    }
                    Rectangle {
                        width: vpx(130); height: vpx(46); radius: vpx(8); color: theme.accent
                        Text { anchors.centerIn: parent; text: tr("Create"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.024); font.bold: true }
                        MouseArea { anchors.fill: parent; onClicked: overlayRoot.commitCreateUser() }
                    }
                    Rectangle {
                        width: vpx(110); height: vpx(46); radius: vpx(8); color: overlayRoot.sheetCard; border.width: 1; border.color: overlayRoot.sheetDivider
                        Text { anchors.centerIn: parent; text: tr("Cancel"); color: overlayRoot.sheetText; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022) }
                        MouseArea { anchors.fill: parent; onClicked: { backSfx.play(); overlayRoot.creatingUser = false; userGrid.forceActiveFocus(); } }
                    }
                }
            }
        }

        Item {
            id: sheetFooter
            anchors { bottom: parent.bottom; left: parent.left; right: parent.right; leftMargin: screenmargin; rightMargin: screenmargin }
            height: Math.round(parent.height * 0.16)
            Rectangle { anchors.top: parent.top; width: parent.width; height: 1; color: overlayRoot.sheetDivider }
            Image { anchors { left: parent.left; verticalCenter: parent.verticalCenter } width: vpx(36); height: vpx(26); source: "../assets/images/navigation/ns2_controller_glyph.svg"; fillMode: Image.PreserveAspectFit; smooth: true }
            Row {
                anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                spacing: vpx(24)
                Row {
                    spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                    Rectangle { width: vpx(26); height: vpx(26); radius: width / 2; color: overlayRoot.sheetText; anchors.verticalCenter: parent.verticalCenter
                        Text { anchors.centerIn: parent; text: "B"; color: overlayRoot.sheetBg; font.family: titleFont.name; font.pixelSize: vpx(14); font.bold: true }
                    }
                    Text { text: tr("Back"); color: overlayRoot.sheetText; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.023); anchors.verticalCenter: parent.verticalCenter }
                    MouseArea { anchors.fill: parent; onClicked: { if (overlayRoot.creatingUser) { overlayRoot.creatingUser = false; userGrid.forceActiveFocus(); } else { overlayRoot.closeCancelled(); } } }
                }
                Row {
                    spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                    Rectangle { width: vpx(26); height: vpx(26); radius: width / 2; color: overlayRoot.sheetText; anchors.verticalCenter: parent.verticalCenter
                        Text { anchors.centerIn: parent; text: "A"; color: overlayRoot.sheetBg; font.family: titleFont.name; font.pixelSize: vpx(14); font.bold: true }
                    }
                    Text { text: tr("OK"); color: overlayRoot.sheetText; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.023); anchors.verticalCenter: parent.verticalCenter }
                    MouseArea { anchors.fill: parent; onClicked: overlayRoot.creatingUser ? overlayRoot.commitCreateUser() : overlayRoot.activateTile(userGrid.currentIndex) }
                }
            }
        }
    }
}
