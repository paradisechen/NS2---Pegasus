// skylineOS 2 — ControllersScreen.qml (Dark #191A1D Switch 2 & RP5 Controller Map)
import QtQuick 2.12

FocusScope {
    id: ctrlRoot
    anchors.fill: parent

    property string gripOrder: api.memory.has("ns2_controller_layout") ? String(api.memory.get("ns2_controller_layout")) : "nintendo"
    property int selectedIndex: 3

    property var mappings: [
        { code: "DPAD", label: "D-Pad", action: "Navigate Library & Menus" },
        { code: "LS", label: "Left Stick", action: "Browse Carousel & Scroll Feeds" },
        { code: "RS", label: "Right Stick", action: "Next / Prev Feed Page" },
        { code: "A", label: "A Button", action: "Start Title / Confirm / Open Story" },
        { code: "B", label: "B Button", action: "Back / Close Overlay" },
        { code: "X", label: "X Button", action: "Toggle Favorite / eShop Wish List" },
        { code: "Y", label: "Y Button", action: "Game Details" },
        { code: "L1", label: "L1 / Lb", action: "Previous Dock Section" },
        { code: "R1", label: "R1 / Rb", action: "Next Dock Section" },
        { code: "L2", label: "ZL / L2", action: "eShop Previous Page" },
        { code: "R2", label: "ZR / R2", action: "eShop Next Page" },
        { code: "+", label: "+ Start", action: "Software + Settings Overlay" }
    ]

    function setLayout(mode) { gripOrder = mode; api.memory.set("ns2_controller_layout", mode); selectSfx.play(); }
    onVisibleChanged: { if (visible) ctrlRoot.forceActiveFocus(); }

    Keys.onLeftPressed: { navSound.play(); selectedIndex = Math.max(0, selectedIndex - 1); }
    Keys.onRightPressed: { navSound.play(); selectedIndex = Math.min(mappings.length - 1, selectedIndex + 1); }
    Keys.onUpPressed: { navSound.play(); selectedIndex = Math.max(0, selectedIndex - 2); }
    Keys.onDownPressed: { navSound.play(); selectedIndex = Math.min(mappings.length - 1, selectedIndex + 2); }
    Keys.onPressed: {
        if (api.keys.isAccept(event) && !event.isAutoRepeat) { event.accepted = true; setLayout(gripOrder === "nintendo" ? "xbox" : "nintendo"); }
        else if (api.keys.isCancel(event) && !event.isAutoRepeat) { event.accepted = true; backSfx.play(); showHomeScreen(); }
    }

    Rectangle { anchors.fill: parent; color: "#191A1D" }

    Item {
        id: ctrlHeader
        anchors { top: parent.top; left: parent.left; right: parent.right; leftMargin: screenmargin; rightMargin: screenmargin }
        height: Math.round(screenheight * 0.108)
        Row {
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            spacing: vpx(12)
            Image { width: vpx(26); height: vpx(26); source: "../assets/images/navigation/ns2_controllers.svg"; fillMode: Image.PreserveAspectFit; smooth: true; anchors.verticalCenter: parent.verticalCenter }
            Text { text: tr("Controllers · Retroid Pocket 5 & Switch 2"); color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.034); font.bold: true; anchors.verticalCenter: parent.verticalCenter }
        }
        Row {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            spacing: vpx(10)
            Rectangle {
                width: vpx(184); height: vpx(34); radius: height / 2; color: ctrlRoot.gripOrder === "nintendo" ? "#0AB9E6" : "#26282E"
                Text { anchors.centerIn: parent; text: tr("Switch 2 Layout (B/A)"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.019); font.bold: true }
                MouseArea { anchors.fill: parent; onClicked: ctrlRoot.setLayout("nintendo") }
            }
            Rectangle {
                width: vpx(164); height: vpx(34); radius: height / 2; color: ctrlRoot.gripOrder === "xbox" ? "#E60012" : "#26282E"
                Text { anchors.centerIn: parent; text: tr("Retro / RP5 Layout"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.019); font.bold: true }
                MouseArea { anchors.fill: parent; onClicked: ctrlRoot.setLayout("xbox") }
            }
        }
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: "#2D3038" }
    }

    Item {
        anchors { top: ctrlHeader.bottom; bottom: ctrlFooter.top; left: parent.left; right: parent.right; margins: vpx(24) }
        Rectangle {
            id: diagramCard
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            width: Math.round(parent.width * 0.42); height: Math.round(parent.height * 0.84)
            radius: vpx(18); color: "#23252B"; border.width: 1; border.color: "#333640"

            Column {
                anchors.centerIn: parent; width: parent.width - vpx(36); spacing: vpx(14)
                Item {
                    width: parent.width; height: vpx(28)
                    Row { anchors.left: parent.left; spacing: vpx(8)
                        Rectangle { width: vpx(36); height: vpx(24); radius: vpx(6); color: "#2E323C"; Text { anchors.centerIn: parent; text: "ZL"; color: "#9CA3AF"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true } }
                        Rectangle { width: vpx(36); height: vpx(24); radius: vpx(6); color: "#0AB9E6"; Text { anchors.centerIn: parent; text: "L"; color: "#191A1D"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true } }
                    }
                    Text { anchors.centerIn: parent; text: tr("P1 · Connected"); color: "#9CA3AF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.019); font.bold: true }
                    Row { anchors.right: parent.right; spacing: vpx(8)
                        Rectangle { width: vpx(36); height: vpx(24); radius: vpx(6); color: "#FF4F5E"; Text { anchors.centerIn: parent; text: "R"; color: "#191A1D"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true } }
                        Rectangle { width: vpx(36); height: vpx(24); radius: vpx(6); color: "#2E323C"; Text { anchors.centerIn: parent; text: "ZR"; color: "#9CA3AF"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true } }
                    }
                }
                Row {
                    width: parent.width; height: Math.round(diagramCard.height * 0.62); spacing: vpx(8)
                    Rectangle {
                        width: vpx(64); height: parent.height; radius: vpx(16); color: "#0A8FB8"
                        Column { anchors.centerIn: parent; spacing: vpx(20)
                            Rectangle { width: vpx(28); height: vpx(28); radius: vpx(14); color: "#191A1D"; anchors.horizontalCenter: parent.horizontalCenter; Text { anchors.centerIn: parent; text: "L"; color: "#FFFFFF"; font.pixelSize: vpx(11); font.bold: true } }
                            Rectangle { width: vpx(28); height: vpx(28); radius: vpx(6); color: "#191A1D"; anchors.horizontalCenter: parent.horizontalCenter; Text { anchors.centerIn: parent; text: "+"; color: "#FFFFFF"; font.pixelSize: vpx(14); font.bold: true } }
                        }
                    }
                    Rectangle {
                        width: parent.width - vpx(144); height: parent.height; radius: vpx(10); color: "#111317"; border.width: 1; border.color: "#2D3038"
                        Column {
                            anchors.centerIn: parent; width: parent.width - vpx(20); spacing: vpx(8)
                            Rectangle { anchors.horizontalCenter: parent.horizontalCenter; width: vpx(46); height: vpx(46); radius: width / 2; color: "#FFFFFF"
                                Text { anchors.centerIn: parent; text: ctrlRoot.mappings[ctrlRoot.selectedIndex].code; color: "#191A1D"; font.family: titleFont.name; font.pixelSize: vpx(14); font.bold: true }
                            }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: ctrlRoot.mappings[ctrlRoot.selectedIndex].label; color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.024); font.bold: true }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; width: parent.width; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; text: ctrlRoot.mappings[ctrlRoot.selectedIndex].action; color: "#38BDF8"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.019) }
                        }
                    }
                    Rectangle {
                        width: vpx(64); height: parent.height; radius: vpx(16); color: "#D92B3A"
                        Column { anchors.centerIn: parent; spacing: vpx(18)
                            Grid {
                                columns: 2; spacing: vpx(6); anchors.horizontalCenter: parent.horizontalCenter
                                Rectangle { width: vpx(18); height: vpx(18); radius: 9; color: "#191A1D"; Text { anchors.centerIn: parent; text: ctrlRoot.gripOrder === "nintendo" ? "X" : "Y"; color: "#FFFFFF"; font.pixelSize: vpx(10); font.bold: true } }
                                Rectangle { width: vpx(18); height: vpx(18); radius: 9; color: "#191A1D"; Text { anchors.centerIn: parent; text: ctrlRoot.gripOrder === "nintendo" ? "A" : "B"; color: "#FFFFFF"; font.pixelSize: vpx(10); font.bold: true } }
                                Rectangle { width: vpx(18); height: vpx(18); radius: 9; color: "#191A1D"; Text { anchors.centerIn: parent; text: ctrlRoot.gripOrder === "nintendo" ? "Y" : "X"; color: "#FFFFFF"; font.pixelSize: vpx(10); font.bold: true } }
                                Rectangle { width: vpx(18); height: vpx(18); radius: 9; color: "#191A1D"; Text { anchors.centerIn: parent; text: ctrlRoot.gripOrder === "nintendo" ? "B" : "A"; color: "#FFFFFF"; font.pixelSize: vpx(10); font.bold: true } }
                            }
                            Rectangle { width: vpx(28); height: vpx(28); radius: vpx(14); color: "#191A1D"; anchors.horizontalCenter: parent.horizontalCenter; Text { anchors.centerIn: parent; text: "R"; color: "#FFFFFF"; font.pixelSize: vpx(11); font.bold: true } }
                        }
                    }
                }
            }
        }

        GridView {
            anchors { left: diagramCard.right; leftMargin: vpx(24); right: parent.right; top: diagramCard.top; bottom: diagramCard.bottom }
            cellWidth: Math.floor(width / 2); cellHeight: Math.floor(height / 6); clip: true
            model: ctrlRoot.mappings
            delegate: Item {
                width: GridView.view.cellWidth; height: GridView.view.cellHeight
                Rectangle {
                    anchors.fill: parent; anchors.margins: vpx(4); radius: vpx(8)
                    color: ctrlRoot.selectedIndex === index ? "#2C303A" : "#23252B"
                    border.width: ctrlRoot.selectedIndex === index ? vpx(2) : 0; border.color: "#0AB9E6"
                    Row {
                        anchors { fill: parent; margins: vpx(10) } spacing: vpx(10)
                        Rectangle { width: vpx(32); height: vpx(32); radius: width / 2; color: "#FFFFFF"; anchors.verticalCenter: parent.verticalCenter
                            Text { anchors.centerIn: parent; text: modelData.code; color: "#191A1D"; font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: true }
                        }
                        Column {
                            width: parent.width - vpx(48); anchors.verticalCenter: parent.verticalCenter
                            Text { width: parent.width; text: modelData.label; color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.020); font.bold: true; elide: Text.ElideRight }
                            Text { width: parent.width; text: modelData.action; color: "#9CA3AF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.017); elide: Text.ElideRight }
                        }
                    }
                    MouseArea { anchors.fill: parent; hoverEnabled: true; onEntered: ctrlRoot.selectedIndex = index; onClicked: { navSound.play(); ctrlRoot.selectedIndex = index; } }
                }
            }
        }
    }

    Item {
        id: ctrlFooter
        anchors { bottom: parent.bottom; left: parent.left; right: parent.right; leftMargin: screenmargin; rightMargin: screenmargin }
        height: Math.round(screenheight * 0.085)
        Rectangle { anchors.top: parent.top; width: parent.width; height: 1; color: "#2D3038" }
        Image { anchors { left: parent.left; verticalCenter: parent.verticalCenter } width: vpx(36); height: vpx(26); source: "../assets/images/navigation/ns2_controller_glyph.svg"; fillMode: Image.PreserveAspectFit; smooth: true }
        Row {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter } spacing: vpx(8)
            Rectangle { width: vpx(26); height: vpx(26); radius: width / 2; color: "#FFFFFF"; anchors.verticalCenter: parent.verticalCenter
                Text { anchors.centerIn: parent; text: "B"; color: "#191A1D"; font.family: titleFont.name; font.pixelSize: vpx(14); font.bold: true }
            }
            Text { text: tr("Back"); color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.023); anchors.verticalCenter: parent.verticalCenter }
            MouseArea { anchors.fill: parent; onClicked: { backSfx.play(); showHomeScreen(); } }
        }
    }
}
