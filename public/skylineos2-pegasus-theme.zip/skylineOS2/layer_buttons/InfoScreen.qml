// skylineOS 2 — InfoScreen.qml (Switch 2 News & Online 2x2 Live Feed + In-Theme Browser Reader)
import QtQuick 2.12
import QtQuick.Layouts 1.3
import QtGraphicalEffects 1.0

FocusScope {
    id: infoScreenRoot
    anchors.fill: parent

    property string entryMode: "news"
    property int activeCategoryIndex: 0
    property int selectedCardIndex: 0
    property int currentPage: 0
    property int cardsPerPage: 4
    property bool isLoading: false
    property bool articleOpen: false
    property string statusNote: ""

    property string selectedTitle: ""
    property string selectedSource: ""
    property string selectedDate: ""
    property string selectedDescription: ""
    property string selectedImageUrl: ""
    property string selectedUrl: ""

    property var allArticles: []

    // All 7 News categories + NSO ("nso") matching React NewsGridView
    property var categories: [
        { id: "news", label: "News", kind: "rss", url: "https://www.nintendolife.com/feeds/latest", source: "Nintendo Life" },
        { id: "sports", label: "Sports", kind: "rss", url: "https://www.espn.com/espn/rss/news", source: "ESPN Sports" },
        { id: "tech", label: "Tech", kind: "rss", url: "https://feeds.arstechnica.com/arstechnica/index", source: "Ars Technica" },
        { id: "android_ports", label: "Android Game Ports", kind: "reddit", url: "https://www.reddit.com/r/EmulationOnAndroid/hot.json?limit=16", source: "r/EmulationOnAndroid" },
        { id: "finance", label: "Finance", kind: "rss", url: "https://finance.yahoo.com/news/rssindex", source: "Yahoo Finance" },
        { id: "politics", label: "Politics", kind: "rss", url: "https://feeds.bbci.co.uk/news/politics/rss.xml", source: "BBC Politics" },
        { id: "puerto_rico", label: "Puerto Rico Noticias", kind: "rss", url: "https://www.elnuevodia.com/arc/outboundfeeds/rss/category/noticias/", source: "El Nuevo Dia" },
        { id: "nso", label: "Online / Switch 2", kind: "rss", url: "https://www.nintendolife.com/feeds/latest", source: "Switch 2 Online" }
    ]

    property var fallbackCatalog: ({
        "news": [
            { title: "Mario Kart World — Knockout Tour & 120Hz Handheld Impressions", source: "Switch 2 News", date: "Today", imageUrl: "", url: "https://www.nintendolife.com", description: "Switch 2 launches with Mario Kart World featuring interconnected routes, 24-racer chaos, and crisp 120Hz portable rendering across every biome." },
            { title: "Donkey Kong Bananza — Destructible Voxel Worlds Explained", source: "Game Spotlight", date: "Featured", imageUrl: "", url: "https://www.nintendolife.com", description: "Smash through underground strata in Donkey Kong Bananza. Every terrain layer hides golden bananas, fossils, and traversal routes built for handheld play." },
            { title: "Metroid Prime 4: Beyond — Mouse-Mode & Performance Targets", source: "Tech Wire", date: "Update", imageUrl: "", url: "https://www.nintendolife.com", description: "Crisp 1080p60 handheld targeting alongside seamless visor scanning and atmospheric spatial audio." },
            { title: "Switch 2 System UI Design Breakdown & Concentric Highlight Rings", source: "UI Spotlight", date: "Article", imageUrl: "", url: "https://www.nintendolife.com", description: "Subtle floating margins, concentric rounded highlights, and crisp UD Shin Go typography define the Switch 2 home screen aesthetic replicated in SkylineOS 2." }
        ],
        "sports": [
            { title: "Championship Finals & Motorsports Weekend Schedule", source: "ESPN Sports", date: "Today", imageUrl: "", url: "https://www.espn.com", description: "Complete matchups, standings, and highlights across basketball, soccer, boxing, and Formula 1." },
            { title: "Esports Fighting & Speedrun Majors Expand Handheld Brackets", source: "Sports Desk", date: "Featured", imageUrl: "", url: "https://www.espn.com", description: "Regional qualifiers draw record attendance with portable console stations and live brackets." },
            { title: "NBA & Liga Superior Season Analytics Roundup", source: "ESPN Sports", date: "Recent", imageUrl: "", url: "https://www.espn.com", description: "Key stats, player efficiency metrics, and upcoming marquee series." },
            { title: "World Athletics & Olympic Qualifier Preview", source: "Sports Desk", date: "Recent", imageUrl: "", url: "https://www.espn.com", description: "Rising sprint and field contenders prepare for international championship meets." }
        ],
        "tech": [
            { title: "Snapdragon Handheld Thermal Tuning & Frame Pacing Deep Dive", source: "Ars Technica", date: "Tech", imageUrl: "", url: "https://arstechnica.com", description: "Evaluating sustained clocks, Turnip GPU drivers, and OLED power draw on modern Snapdragon 865 handhelds." },
            { title: "Open-Source Mesa Turnip Drivers Boost Vulkan Rendering Speeds", source: "Ars Technica", date: "Update", imageUrl: "", url: "https://arstechnica.com", description: "Recent Adreno Vulkan extensions cut shader compilation stutter in demanding console ports and native games." },
            { title: "Qt5 & Embedded Linux Frontend Optimization for Handhelds", source: "Tech Wire", date: "Recent", imageUrl: "", url: "https://arstechnica.com", description: "How hardware-accelerated scene graphs keep frontend navigation fluid at 60fps and 120fps." },
            { title: "Wi-Fi 6 & Low-Latency Cloud Game Streaming Benchmarks", source: "Ars Technica", date: "Recent", imageUrl: "", url: "https://arstechnica.com", description: "Comparing decode latency and controller polling rates across modern Android handhelds." }
        ],
        "android_ports": [
            { title: "Retroid Pocket 5 Snapdragon 865 Driver & Eden Direct Boot Guide", source: "r/EmulationOnAndroid", date: "Community", imageUrl: "", url: "https://old.reddit.com/r/EmulationOnAndroid/", description: "Launch games straight into Eden EmulationActivity from SkylineOS 2 with zero duplicate launch prompts, crisp Turnip driver profiles, and 1080p scaling." },
            { title: "Hollow Knight: Silksong & Celeste Native Android Port Notes", source: "r/EmulationOnAndroid", date: "Community", imageUrl: "", url: "https://old.reddit.com/r/EmulationOnAndroid/", description: "Native controller mapping tips and recommended texture settings for 16:9 widescreen handheld screens." },
            { title: "Ship of Harkinian & RSDKv5 Decompilations at Locked 60fps", source: "r/EmulationOnAndroid", date: "Community", imageUrl: "", url: "https://old.reddit.com/r/EmulationOnAndroid/", description: "Community presets for widescreen HUD layouts and instant save-state sync." },
            { title: "Half-Life 2 & Portal Source Engine Port Tuning on RP5", source: "r/EmulationOnAndroid", date: "Community", imageUrl: "", url: "https://old.reddit.com/r/EmulationOnAndroid/", description: "Analog deadzone calibration and high-contrast shader presets for OLED screens." }
        ],
        "finance": [
            { title: "Semiconductor & Handheld Hardware Supply Chain Update", source: "Yahoo Finance", date: "Markets", imageUrl: "", url: "https://finance.yahoo.com", description: "OLED panel pricing and mobile SoC shipments reflect surging demand for portable gaming hardware." },
            { title: "Global Console & Digital Software Spending Trends", source: "Market Watch", date: "Markets", imageUrl: "", url: "https://finance.yahoo.com", description: "Digital downloads and indie releases continue to drive year-over-year handheld software growth." },
            { title: "Memory & Flash Storage Contract Pricing Outlook", source: "Yahoo Finance", date: "Markets", imageUrl: "", url: "https://finance.yahoo.com", description: "MicroSD Express and UFS 3.1 module costs stabilize across consumer electronics." },
            { title: "Quarterly Tech Earnings & Consumer Electronics Index", source: "Yahoo Finance", date: "Markets", imageUrl: "", url: "https://finance.yahoo.com", description: "Key takeaways from semiconductor and entertainment hardware earnings calls." }
        ],
        "politics": [
            { title: "Right-to-Repair & Consumer Battery Rules Expand Worldwide", source: "BBC Politics", date: "Policy", imageUrl: "", url: "https://www.bbc.com/news/politics", description: "New standards encourage accessible replacement batteries and repair documentation for handheld devices." },
            { title: "Digital Marketplace & App Store Interoperability Updates", source: "BBC Politics", date: "Policy", imageUrl: "", url: "https://www.bbc.com/news/politics", description: "Regulators review sideloading, third-party storefronts, and open browser engine policies." },
            { title: "International Trade & Hardware Tariff Briefings", source: "BBC Politics", date: "World", imageUrl: "", url: "https://www.bbc.com/news/politics", description: "Updates on consumer electronics supply routes and customs frameworks." },
            { title: "Public Broadband & Rural Fiber Connectivity Initiatives", source: "BBC Politics", date: "Policy", imageUrl: "", url: "https://www.bbc.com/news/politics", description: "Infrastructure grants expand gigabit residential fiber coverage across regional communities." }
        ],
        "puerto_rico": [
            { title: "Actualidad y Noticias de Puerto Rico — Resumen del Dia", source: "El Nuevo Dia", date: "Santurce, PR", imageUrl: "", url: "https://www.elnuevodia.com", description: "Cobertura de noticias locales, comunidad, cultura y desarrollo tecnologico en Puerto Rico." },
            { title: "Escena Gaming y Torneos Comunitarios en el Area Metro", source: "Puerto Rico Noticias", date: "PR", imageUrl: "", url: "https://www.elnuevodia.com", description: "Comunidades locales organizan torneos de consola portatil y encuentros de desarrolladores independientes." },
            { title: "Infraestructura y Energia: Reporte Semanal en la Isla", source: "El Nuevo Dia", date: "PR", imageUrl: "", url: "https://www.elnuevodia.com", description: "Actualizaciones sobre proyectos comunitarios, microrredes solares y telecomunicaciones." },
            { title: "Cultura, Musica y Eventos en Santurce y Viejo San Juan", source: "Puerto Rico Noticias", date: "PR", imageUrl: "", url: "https://www.elnuevodia.com", description: "Agenda cultural de exhibiciones, cine independiente y festivales locales." }
        ],
        "nso": [
            { title: "Nintendo Switch Online — GameCube Classics Library Spotlight", source: "Switch 2 Online", date: "NSO", imageUrl: "", url: "https://www.nintendolife.com", description: "Classic titles rendered in crisp widescreen with online lobbies, rewind support, and customizable button presets." },
            { title: "Mario Kart World Online Knockout Rooms & Friends Lobbies", source: "Switch 2 Online", date: "NSO", imageUrl: "", url: "https://www.nintendolife.com", description: "Jump into 24-player Knockout Tours or invite friends straight from your active user profile." },
            { title: "Save Data Cloud & Play Activity Sync Across Handhelds", source: "Switch 2 Online", date: "Service", imageUrl: "", url: "https://www.nintendolife.com", description: "Track hours played per title and manage your favorites and play backlog seamlessly." },
            { title: "Weekly Classic Library Drops & Soundtracks", source: "Switch 2 Online", date: "NSO", imageUrl: "", url: "https://www.nintendolife.com", description: "Explore curated retro releases, multiplayer challenges, and iconic game soundtracks." }
        ]
    })

    ListModel { id: pageModel }

    function openSection(mode) {
        entryMode = (mode === "nso") ? "nso" : "news";
        articleOpen = false;
        activeCategoryIndex = (entryMode === "nso") ? 7 : 0;
        currentPage = 0;
        selectedCardIndex = 0;
        fetchActiveCategory();
    }

    function cleanText(raw) {
        if (!raw) return "";
        var s = String(raw);
        s = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
        s = s.replace(/<[^>]+>/g, " ");
        s = s.replace(/&amp;/g, "&").replace(/&quot;/g, "\"").replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ");
        s = s.replace(/\s+/g, " ").trim();
        return s;
    }

    function totalPages() {
        return Math.max(1, Math.ceil(allArticles.length / cardsPerPage));
    }

    function rebuildPage() {
        pageModel.clear();
        var tp = totalPages();
        if (currentPage >= tp) currentPage = tp - 1;
        if (currentPage < 0) currentPage = 0;
        var start = currentPage * cardsPerPage;
        var end = Math.min(allArticles.length, start + cardsPerPage);
        for (var i = start; i < end; i++) {
            var it = allArticles[i];
            pageModel.append({
                articleTitle: it.title || "Untitled",
                articleSource: it.source || "",
                articleDate: it.date || "",
                articleDescription: it.description || "",
                articleImageUrl: it.imageUrl || "",
                articleUrl: it.url || ""
            });
        }
        if (selectedCardIndex >= pageModel.count) selectedCardIndex = Math.max(0, pageModel.count - 1);
    }

    function fetchActiveCategory() {
        var cat = categories[activeCategoryIndex];
        if (!cat) return;
        isLoading = true;
        statusNote = tr("Refreshing live feed...") + " (" + cat.source + ")";

        var fb = fallbackCatalog[cat.id] || fallbackCatalog["news"];
        allArticles = fb.slice(0);
        currentPage = 0;
        rebuildPage();

        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return;
            isLoading = false;
            var parsed = [];
            if (xhr.status >= 200 && xhr.status < 400 && xhr.responseText) {
                if (cat.kind === "reddit") parsed = parseRedditJson(xhr.responseText, cat.source);
                else parsed = parseRssXml(xhr.responseText, cat.source);
            }
            if (parsed.length > 0) {
                allArticles = parsed;
                statusNote = cat.source + " · " + parsed.length + " " + tr("stories");
                currentPage = 0;
                rebuildPage();
            } else {
                statusNote = cat.source + " · " + allArticles.length + " " + tr("stories");
            }
        };
        xhr.open("GET", cat.url);
        xhr.send();
    }

    function parseRedditJson(rawJson, sourceLabel) {
        var out = [];
        try {
            var data = JSON.parse(rawJson);
            var children = (data && data.data && data.data.children) ? data.data.children : [];
            for (var i = 0; i < children.length && out.length < 16; i++) {
                var p = children[i].data;
                if (!p || !p.title) continue;
                var img = "";
                if (p.thumbnail && p.thumbnail.indexOf("http") === 0) img = p.thumbnail;
                var desc = cleanText(p.selftext || "");
                if (desc.length < 16) desc = p.title + " — " + tr("Open in In-Theme Browser to view the complete thread.");
                out.push({
                    title: cleanText(p.title),
                    source: sourceLabel,
                    date: (p.ups ? (p.ups + " pts") : "Community"),
                    imageUrl: img,
                    url: "https://old.reddit.com" + (p.permalink || "/r/EmulationOnAndroid/"),
                    description: desc
                });
            }
        } catch (e) {}
        return out;
    }

    function parseRssXml(xmlText, sourceLabel) {
        var out = [];
        var itemRegex = /<(item|entry)([\s\S]*?)<\/\1>/gi;
        var match;
        while ((match = itemRegex.exec(xmlText)) !== null && out.length < 16) {
            var block = match[0];
            var titleM = block.match(/<title[^>]*>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/title>/i);
            var linkM = block.match(/<link[^>]+href=["']([^"']+)["']/i)
                     || block.match(/<link[^>]*>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/link>/i);
            var dateM = block.match(/<(?:pubDate|published|updated|dc:date)[^>]*>([\s\S]*?)<\/(?:pubDate|published|updated|dc:date)>/i);
            var imgM = block.match(/enclosure[^>]+url=["'](https?[^"']+)["']/i)
                    || block.match(/media:(?:content|thumbnail)[^>]+url=["'](https?[^"']+)["']/i)
                    || block.match(/<img[^>]+src=["'](https?[^"']+)["']/i);
            var descM = block.match(/<(?:content:encoded|description|summary|content)[^>]*>\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*<\/(?:content:encoded|description|summary|content)>/i)
                     || block.match(/<(?:content:encoded|description|summary|content)[^>]*>([\s\S]*?)<\/(?:content:encoded|description|summary|content)>/i);
            var title = cleanText(titleM ? titleM[1] : "");
            if (!title) continue;
            var linkUrl = linkM ? cleanText(linkM[1]) : "";
            var dateStr = dateM ? cleanText(dateM[1]).substring(0, 22) : "Recent";
            var imgUrl = imgM ? imgM[1].trim() : "";
            var desc = cleanText(descM ? descM[1] : "");
            if (desc.length < 16) desc = title + " — " + tr("Open in In-Theme Browser to read the full story.");
            out.push({ title: title, source: sourceLabel, date: dateStr, imageUrl: imgUrl, url: linkUrl, description: desc });
        }
        return out;
    }

    function openArticleAt(idx) {
        if (idx < 0 || idx >= pageModel.count) return;
        var item = pageModel.get(idx);
        selectedTitle = item.articleTitle || "";
        selectedSource = item.articleSource || "";
        selectedDate = item.articleDate || "";
        selectedDescription = item.articleDescription || "";
        selectedImageUrl = item.articleImageUrl || "";
        selectedUrl = item.articleUrl || "";
        articleOpen = true;
        selectSfx.play();
    }

    function openSelectedStoryInBrowser() {
        var u = selectedUrl;
        if (!u || u === "") return;
        selectSfx.play();
        if (settings.browserMode === "chrome") Qt.openUrlExternally(u);
        else openInThemeBrowser(u);
    }

    onVisibleChanged: {
        if (visible) {
            if (allArticles.length === 0) fetchActiveCategory();
            infoScreenRoot.forceActiveFocus();
        }
    }

    Component.onCompleted: {
        allArticles = fallbackCatalog["news"].slice(0);
        rebuildPage();
    }

    Keys.onLeftPressed: {
        if (articleOpen || pageModel.count === 0) return;
        navSound.play();
        selectedCardIndex = selectedCardIndex > 0 ? selectedCardIndex - 1 : pageModel.count - 1;
    }
    Keys.onRightPressed: {
        if (articleOpen || pageModel.count === 0) return;
        navSound.play();
        selectedCardIndex = (selectedCardIndex + 1) % pageModel.count;
    }
    Keys.onUpPressed: {
        if (articleOpen || pageModel.count === 0) return;
        navSound.play();
        if (selectedCardIndex >= 2) selectedCardIndex -= 2;
    }
    Keys.onDownPressed: {
        if (articleOpen || pageModel.count === 0) return;
        navSound.play();
        if (selectedCardIndex + 2 < pageModel.count) selectedCardIndex += 2;
    }
    Keys.onPressed: {
        if (articleOpen) {
            if (api.keys.isCancel(event) && !event.isAutoRepeat) {
                event.accepted = true; backSfx.play(); articleOpen = false;
            } else if (api.keys.isAccept(event) && !event.isAutoRepeat) {
                event.accepted = true; openSelectedStoryInBrowser();
            }
            return;
        }
        if (api.keys.isAccept(event) && !event.isAutoRepeat) {
            event.accepted = true; openArticleAt(selectedCardIndex);
        } else if (api.keys.isDetails(event) && !event.isAutoRepeat) {
            event.accepted = true; navSound.play(); fetchActiveCategory();
        } else if (api.keys.isPrevPage(event) && !event.isAutoRepeat) {
            event.accepted = true;
            if (currentPage > 0) { navSound.play(); currentPage--; selectedCardIndex = 0; rebuildPage(); }
        } else if (api.keys.isNextPage(event) && !event.isAutoRepeat) {
            event.accepted = true;
            if (currentPage + 1 < totalPages()) { navSound.play(); currentPage++; selectedCardIndex = 0; rebuildPage(); }
        } else if (api.keys.isCancel(event) && !event.isAutoRepeat) {
            event.accepted = true; backSfx.play(); showHomeScreen();
        }
    }

    property bool isDarkPage: (settings.appearanceMode === "Dark") || (settings.appearanceMode === "Auto" && settings.darkMode === "Yes")
    property color pageBg: isDarkPage ? "#191B20" : "#EFEFEF"
    property color cardBg: isDarkPage ? "#242730" : "#FFFFFF"
    property color textMain: isDarkPage ? "#F3F4F6" : "#1F2329"
    property color textMuted: isDarkPage ? "#9CA3AF" : "#5E6570"
    property color dividerColor: isDarkPage ? "#353944" : "#C8C8C8"

    Rectangle { anchors.fill: parent; color: infoScreenRoot.pageBg }

    // Top Header Row
    Item {
        id: infoHeader
        anchors { top: parent.top; left: parent.left; right: parent.right; leftMargin: screenmargin; rightMargin: screenmargin }
        height: Math.round(screenheight * 0.108)

        Row {
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            spacing: vpx(14)

            Image {
                width: vpx(32); height: vpx(32)
                source: infoScreenRoot.activeCategoryIndex === 7 ? "../assets/images/navigation/ns2_online.svg" : "../assets/images/navigation/ns2_news.svg"
                fillMode: Image.PreserveAspectFit; smooth: true
                anchors.verticalCenter: parent.verticalCenter
            }
            Column {
                anchors.verticalCenter: parent.verticalCenter
                spacing: vpx(2)
                Text {
                    text: infoScreenRoot.entryMode === "nso" ? tr("Switch 2 News & NSO · Online") : tr("Switch 2 News & NSO")
                    color: infoScreenRoot.textMain
                    font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.034); font.bold: true
                }
                Text {
                    text: infoScreenRoot.isLoading ? tr("Refreshing live feed...") : infoScreenRoot.statusNote
                    color: infoScreenRoot.textMuted
                    font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.018)
                }
            }
        }

        Rectangle {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            width: refreshLbl.implicitWidth + vpx(26); height: vpx(34); radius: height / 2
            color: infoScreenRoot.cardBg; border.width: vpx(2); border.color: theme.accent
            Text { id: refreshLbl; anchors.centerIn: parent; text: infoScreenRoot.isLoading ? "..." : tr("X  Refresh Feed"); color: theme.accent; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
            MouseArea { anchors.fill: parent; onClicked: { navSound.play(); infoScreenRoot.fetchActiveCategory(); } }
        }
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: infoScreenRoot.dividerColor }
    }

    // Category Pills Strip (All 7 News Categories + Online)
    Flickable {
        id: catStrip
        anchors { top: infoHeader.bottom; topMargin: vpx(10); left: parent.left; right: parent.right; leftMargin: screenmargin; rightMargin: screenmargin }
        height: vpx(36)
        contentWidth: catRow.width
        clip: true

        Row {
            id: catRow
            spacing: vpx(8)
            Repeater {
                model: infoScreenRoot.categories
                delegate: Rectangle {
                    property bool active: index === infoScreenRoot.activeCategoryIndex
                    width: catLbl.implicitWidth + vpx(26); height: vpx(34); radius: height / 2
                    color: active ? theme.accent : infoScreenRoot.cardBg
                    border.width: active ? 0 : 1
                    border.color: infoScreenRoot.dividerColor
                    Text { id: catLbl; anchors.centerIn: parent; text: tr(modelData.label); color: active ? "#FFFFFF" : infoScreenRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: active }
                    MouseArea {
                        anchors.fill: parent
                        onClicked: {
                            navSound.play();
                            infoScreenRoot.articleOpen = false;
                            infoScreenRoot.activeCategoryIndex = index;
                            infoScreenRoot.selectedCardIndex = 0;
                            infoScreenRoot.fetchActiveCategory();
                        }
                    }
                }
            }
        }
    }

    // 2x2 Switch 2 News Card Grid
    GridView {
        id: newsGrid
        visible: !infoScreenRoot.articleOpen
        anchors { top: catStrip.bottom; topMargin: vpx(12); left: parent.left; right: parent.right; bottom: infoFooter.top; leftMargin: screenmargin; rightMargin: screenmargin; bottomMargin: vpx(10) }
        cellWidth: Math.floor(width / 2)
        cellHeight: Math.floor(height / 2)
        interactive: false
        clip: true
        model: pageModel

        delegate: Item {
            width: newsGrid.cellWidth; height: newsGrid.cellHeight
            property bool focusedCard: index === infoScreenRoot.selectedCardIndex

            Rectangle {
                anchors { fill: parent; margins: vpx(8) }
                radius: vpx(10)
                color: infoScreenRoot.cardBg
                border.width: focusedCard ? vpx(3) : 1
                border.color: focusedCard ? theme.accent : infoScreenRoot.dividerColor
                clip: true

                Row {
                    anchors.fill: parent

                    // Left Thumbnail
                    Item {
                        width: Math.round(parent.width * 0.36); height: parent.height
                        Rectangle { anchors.fill: parent; color: theme.accent; opacity: 0.16 }
                        Image { anchors.fill: parent; source: model.articleImageUrl; fillMode: Image.PreserveAspectCrop; asynchronous: true; smooth: true }
                        Text {
                            visible: model.articleImageUrl === ""
                            anchors.centerIn: parent; text: model.articleSource.substring(0, 2).toUpperCase()
                            color: theme.accent; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.04); font.bold: true
                        }
                    }

                    // Right Copy
                    Item {
                        width: parent.width - Math.round(parent.width * 0.36)
                        height: parent.height
                        Column {
                            anchors { fill: parent; margins: vpx(14) }
                            spacing: vpx(6)

                        Row {
                            spacing: vpx(8)
                            Rectangle {
                                width: srcBadgeTxt.implicitWidth + vpx(12); height: vpx(20); radius: vpx(4)
                                color: theme.accent; opacity: 0.18
                            }
                            Text {
                                id: srcBadgeTxt
                                text: model.articleSource + (model.articleDate !== "" ? (" · " + model.articleDate) : "")
                                color: theme.accent; font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: true
                            }
                        }

                        Text {
                            width: parent.width
                            text: model.articleTitle
                            color: infoScreenRoot.textMain
                            font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.023); font.bold: true
                            wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight
                        }

                        Text {
                            width: parent.width
                            text: model.articleDescription
                            color: infoScreenRoot.textMuted
                            font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.018)
                            wrapMode: Text.WordWrap; maximumLineCount: 3; elide: Text.ElideRight
                        }
                        }
                    }
                }

                MouseArea {
                    anchors.fill: parent
                    onClicked: { infoScreenRoot.selectedCardIndex = index; infoScreenRoot.openArticleAt(index); }
                }
            }
        }
    }

    // In-Screen Story Reader Modal
    Rectangle {
        visible: infoScreenRoot.articleOpen
        anchors { top: catStrip.bottom; topMargin: vpx(12); left: parent.left; right: parent.right; bottom: infoFooter.top; leftMargin: screenmargin; rightMargin: screenmargin; bottomMargin: vpx(10) }
        radius: vpx(12); color: infoScreenRoot.cardBg; border.width: 1; border.color: infoScreenRoot.dividerColor

        Flickable {
            anchors { fill: parent; margins: vpx(24); bottomMargin: vpx(68) }
            contentHeight: readerCol.height; clip: true

            Column {
                id: readerCol
                width: parent.width; spacing: vpx(12)

                Text { text: infoScreenRoot.selectedSource + (infoScreenRoot.selectedDate !== "" ? (" · " + infoScreenRoot.selectedDate) : ""); color: theme.accent; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                Text { width: parent.width; wrapMode: Text.WordWrap; text: infoScreenRoot.selectedTitle; color: infoScreenRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.032); font.bold: true }
                Rectangle { width: parent.width; height: 1; color: infoScreenRoot.dividerColor }
                Image {
                    visible: infoScreenRoot.selectedImageUrl !== ""
                    width: parent.width; height: visible ? Math.round(screenheight * 0.28) : 0
                    source: infoScreenRoot.selectedImageUrl; fillMode: Image.PreserveAspectCrop; smooth: true
                }
                Text { width: parent.width; wrapMode: Text.WordWrap; text: infoScreenRoot.selectedDescription; color: infoScreenRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022); lineHeight: 1.42 }
            }
        }

        Row {
            anchors { right: parent.right; bottom: parent.bottom; margins: vpx(18) }
            spacing: vpx(12)
            Rectangle {
                width: vpx(140); height: vpx(38); radius: vpx(8); color: infoScreenRoot.pageBg; border.width: 1; border.color: infoScreenRoot.dividerColor
                Text { anchors.centerIn: parent; text: tr("Back to Grid"); color: infoScreenRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                MouseArea { anchors.fill: parent; onClicked: { backSfx.play(); infoScreenRoot.articleOpen = false; } }
            }
            Rectangle {
                visible: infoScreenRoot.selectedUrl !== ""
                width: vpx(220); height: vpx(38); radius: vpx(8); color: theme.accent
                Text { anchors.centerIn: parent; text: tr("Open in In-Theme Browser"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                MouseArea { anchors.fill: parent; onClicked: infoScreenRoot.openSelectedStoryInBrowser() }
            }
        }
    }

    // Bottom Switch 2 Footer Bar
    Item {
        id: infoFooter
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: screenmargin; rightMargin: screenmargin }
        height: Math.round(screenheight * 0.088)
        Rectangle { anchors.top: parent.top; width: parent.width; height: 1; color: infoScreenRoot.dividerColor }

        Row {
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            spacing: vpx(16)
            Image {
                width: vpx(36); height: vpx(26)
                source: "../assets/images/navigation/ns2_controller_glyph.svg"
                fillMode: Image.PreserveAspectFit; smooth: true; anchors.verticalCenter: parent.verticalCenter
                layer.enabled: true; layer.effect: ColorOverlay { color: infoScreenRoot.textMain; antialiasing: true; cached: true }
            }
            Text {
                visible: !infoScreenRoot.articleOpen
                anchors.verticalCenter: parent.verticalCenter
                text: "L1 / R2  ·  Page " + (infoScreenRoot.currentPage + 1) + " / " + infoScreenRoot.totalPages()
                color: infoScreenRoot.textMuted; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.020)
            }
        }

        Row {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            spacing: vpx(22)
            Row {
                spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: infoScreenRoot.textMain; anchors.verticalCenter: parent.verticalCenter
                    Text { anchors.centerIn: parent; text: "B"; color: infoScreenRoot.pageBg; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                }
                Text { text: tr("Back"); color: infoScreenRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022); anchors.verticalCenter: parent.verticalCenter }
                MouseArea { anchors.fill: parent; onClicked: { backSfx.play(); if (infoScreenRoot.articleOpen) infoScreenRoot.articleOpen = false; else showHomeScreen(); } }
            }
            Row {
                spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: infoScreenRoot.textMain; anchors.verticalCenter: parent.verticalCenter
                    Text { anchors.centerIn: parent; text: "A"; color: infoScreenRoot.pageBg; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                }
                Text { text: infoScreenRoot.articleOpen ? tr("Open Story") : tr("Read Story"); color: infoScreenRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022); anchors.verticalCenter: parent.verticalCenter }
                MouseArea { anchors.fill: parent; onClicked: { if (infoScreenRoot.articleOpen) infoScreenRoot.openSelectedStoryInBrowser(); else infoScreenRoot.openArticleAt(infoScreenRoot.selectedCardIndex); } }
            }
        }
    }
}
