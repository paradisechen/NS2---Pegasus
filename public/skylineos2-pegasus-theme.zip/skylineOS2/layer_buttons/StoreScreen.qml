// skylineOS 2 — StoreScreen.qml (Switch 2 Dark eShop + APKPorts Live Integration)
import QtQuick 2.12
import QtQuick.Layouts 1.3
import QtGraphicalEffects 1.0

FocusScope {
    id: storeRoot
    anchors.fill: parent

    property string activeSection: "highlights"
    property string sortMode: "popular"
    property string selectedCategory: ""
    property bool showFilters: false
    property string searchQuery: ""
    property bool editingSearch: false
    property int selectedIndex: 0
    property int currentPage: 0
    property int itemsPerPage: 6
    property bool isLoading: false
    property bool detailOpen: false
    property var detailGame: null
    property string statusBanner: "Select Any Title to Download directly to your Device"
    property string subBanner: "This are Unofficial ports & results may vary"

    property var wishlistSlugs: api.memory.has("ESHOP_WISHLIST") ? api.memory.get("ESHOP_WISHLIST") : []
    property var allGamesCache: []

    property var sections: [
        { id: "highlights", label: "Highlights" },
        { id: "search", label: "Search" },
        { id: "forYou", label: "For You" },
        { id: "wishlist", label: "Wish List" },
        { id: "official", label: "Official Ports" },
        { id: "unofficial", label: "Unofficial Ports" },
        { id: "charts", label: "Charts" },
        { id: "recent", label: "Recent Releases" },
        { id: "fan-games", label: "Fan Games" }
    ]

    property var genreChips: [
        { slug: "", name: "All Genres" },
        { slug: "action", name: "Action" },
        { slug: "adventure", name: "Adventure" },
        { slug: "rpg", name: "RPG" },
        { slug: "platformer", name: "Platformer" },
        { slug: "racing", name: "Racing" },
        { slug: "shooter", name: "Shooter" },
        { slug: "indie", name: "Indie" }
    ]

    property var fallbackCatalog: [
        { slug: "hollow-knight-silksong", title: "Hollow Knight: Silksong", version: "1.0.2", portType: "unofficial", category: "Metroidvania", dev: "Team Cherry / Port", desc: "Explore a haunting kingdom of silk and song on Android handhelds.", cover: "https://www.apkports.com/uploads/thumbs/silksong.webp" },
        { slug: "celeste-android", title: "Celeste", version: "1.4.0", portType: "unofficial", category: "Platformer", dev: "Maddy Makes Games / Port", desc: "Help Madeline survive her inner demons on her journey to the top of Celeste Mountain.", cover: "https://www.apkports.com/uploads/thumbs/celeste.webp" },
        { slug: "cuphead-android", title: "Cuphead", version: "1.3.4", portType: "unofficial", category: "Action", dev: "Studio MDHR / Community", desc: "Classic run-and-gun action inspired by 1930s cartoons with full controller support.", cover: "https://www.apkports.com/uploads/thumbs/cuphead.webp" },
        { slug: "gta-san-andreas-de", title: "GTA: San Andreas Definitive", version: "2.11", portType: "official", category: "Open World", dev: "Rockstar Games", desc: "Official Android port updated with high-res textures and modern analog controls.", cover: "https://www.apkports.com/uploads/thumbs/gtasa.webp" },
        { slug: "sonic-mania-plus", title: "Sonic Mania Plus", version: "5.2.0", portType: "unofficial", category: "Platformer", dev: "RSDKv5 Decomp", desc: "Decompilation Android port supporting 16:9 widescreen & Encore mode.", cover: "https://www.apkports.com/uploads/thumbs/sonic-mania.webp" },
        { slug: "ship-of-harkinian", title: "Ship of Harkinian (OoT)", version: "8.0.6", portType: "unofficial", category: "Adventure", dev: "Harbour Masters", desc: "Ocarina of Time native Android port at 60fps with free camera & widescreen.", cover: "https://www.apkports.com/uploads/thumbs/soh.webp" },
        { slug: "undertale-android", title: "Undertale", version: "1.08", portType: "unofficial", category: "RPG", dev: "Toby Fox / Community", desc: "Classic RPG ported for Android with gamepad overlay support.", cover: "https://www.apkports.com/uploads/thumbs/undertale.webp" },
        { slug: "half-life-2-android", title: "Half-Life 2", version: "1.14", portType: "unofficial", category: "Shooter", dev: "nillerusr / Source Engine", desc: "Full Source Engine Android port running smoothly on Retroid Pocket 5.", cover: "https://www.apkports.com/uploads/thumbs/hl2.webp" },
        { slug: "portal-android", title: "Portal", version: "1.14", portType: "unofficial", category: "Puzzle", dev: "nillerusr / Source Engine", desc: "Valve's iconic puzzle-platformer natively on Android.", cover: "https://www.apkports.com/uploads/thumbs/portal.webp" },
        { slug: "tmnt-shredders-revenge", title: "TMNT: Shredder's Revenge", version: "1.2.12", portType: "official", category: "Arcade", dev: "Tribute Games", desc: "Arcade beat-em-up with crisp pixel art and multiplayer support.", cover: "https://www.apkports.com/uploads/thumbs/tmnt.webp" },
        { slug: "alien-isolation", title: "Alien: Isolation", version: "1.2.3", portType: "official", category: "Horror", dev: "Feral Interactive", desc: "Console-grade survival horror ported cleanly to Android.", cover: "https://www.apkports.com/uploads/thumbs/alien-isolation.webp" },
        { slug: "sm64-coop-dx", title: "Super Mario 64 Coop DX", version: "1.3", portType: "fan-games", category: "Fan Game", dev: "sm64coopdx", desc: "Native 60fps widescreen SM64 Android port with online co-op.", cover: "https://www.apkports.com/uploads/thumbs/sm64.webp" }
    ]

    ListModel { id: filteredModel }
    ListModel { id: pageGridModel }

    function isWishlisted(slug) {
        for (var i = 0; i < wishlistSlugs.length; i++) {
            if (wishlistSlugs[i] === slug) return true;
        }
        return false;
    }

    function toggleWishlist(slug) {
        if (!slug || slug === "") return;
        var next = wishlistSlugs.slice(0);
        var foundAt = -1;
        for (var i = 0; i < next.length; i++) {
            if (next[i] === slug) { foundAt = i; break; }
        }
        if (foundAt >= 0) {
            next.splice(foundAt, 1);
            turnOffSfx.play();
        } else {
            next.push(slug);
            turnOnSfx.play();
        }
        wishlistSlugs = next;
        api.memory.set("ESHOP_WISHLIST", next);
        if (activeSection === "wishlist") rebuildGrid();
    }

    function totalPages() {
        var cnt = filteredModel.count;
        return Math.max(1, Math.ceil(cnt / itemsPerPage));
    }

    function rebuildPageSlice() {
        pageGridModel.clear();
        var tp = totalPages();
        if (currentPage >= tp) currentPage = tp - 1;
        if (currentPage < 0) currentPage = 0;
        var start = currentPage * itemsPerPage;
        var end = Math.min(filteredModel.count, start + itemsPerPage);
        for (var i = start; i < end; i++) {
            pageGridModel.append(filteredModel.get(i));
        }
        if (selectedIndex >= pageGridModel.count) selectedIndex = Math.max(0, pageGridModel.count - 1);
    }

    function rebuildGrid() {
        filteredModel.clear();
        var base = allGamesCache.length > 0 ? allGamesCache : fallbackCatalog;
        var q = String(searchQuery || "").trim().toLowerCase();
        var catLower = String(selectedCategory || "").trim().toLowerCase();
        var arr = [];

        for (var i = 0; i < base.length; i++) {
            var g = base[i];
            if (activeSection === "official" && g.portType !== "official") continue;
            if (activeSection === "unofficial" && g.portType !== "unofficial") continue;
            if (activeSection === "fan-games" && g.portType !== "fan-games") continue;
            if (activeSection === "wishlist" && !isWishlisted(g.slug)) continue;
            if (catLower !== "") {
                var c = String(g.category || "APK Port").toLowerCase();
                if (c.indexOf(catLower) < 0 && String(g.desc || "").toLowerCase().indexOf(catLower) < 0) continue;
            }
            if (q !== "") {
                var hay = (String(g.title || "") + " " + String(g.dev || "") + " " + String(g.category || "")).toLowerCase();
                if (hay.indexOf(q) < 0) continue;
            }
            arr.push(g);
        }

        if (sortMode === "title") {
            arr.sort(function(a, b) {
                var ta = String(a.title || "").toLowerCase();
                var tb = String(b.title || "").toLowerCase();
                return ta < tb ? -1 : (ta > tb ? 1 : 0);
            });
        } else if (sortMode === "newest") {
            arr = arr.slice(0).reverse();
        }

        for (var j = 0; j < arr.length; j++) {
            var it = arr[j];
            filteredModel.append({
                slug: String(it.slug || ""),
                title: String(it.title || ""),
                version: String(it.version || "1.0"),
                portType: String(it.portType || "unofficial"),
                category: String(it.category || "APK Port"),
                dev: String(it.dev || "APKPorts.com"),
                desc: String(it.desc || ""),
                cover: String(it.cover || "")
            });
        }
        currentPage = 0;
        selectedIndex = 0;
        rebuildPageSlice();
    }

    function parseApkPortsHtml(html) {
        var results = [];
        var seen = {};
        if (!html || html.length < 40) return results;
        var cardRe = /<a[^>]+href=["'](?:https?:\/\/www\.apkports\.com)?\/game\/([^"'?#\/]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
        var m;
        while ((m = cardRe.exec(html)) !== null && results.length < 60) {
            var slug = m[1].trim();
            if (!slug || seen[slug]) continue;
            var block = m[2];
            var imgM = block.match(/<img[^>]+(?:data-src|src)=["']([^"']+)["']/i);
            var hM = block.match(/<(?:h2|h3|h4|span|div)[^>]*>([^<]{2,64})<\/(?:h2|h3|h4|span|div)>/i);
            var title = hM ? hM[1].replace(/\s+/g, " ").trim() : slug.replace(/-/g, " ");
            if (title.length < 2) continue;
            var verM = block.match(/v?(\d+\.\d+(?:\.\d+)?)/i);
            var cover = imgM ? imgM[1].trim() : "";
            if (cover.indexOf("/") === 0) cover = "https://www.apkports.com" + cover;
            seen[slug] = true;
            results.push({
                slug: slug,
                title: title,
                version: verM ? verM[1] : "Latest",
                portType: activeSection === "fan-games" ? "fan-games" : (/official/i.test(block) ? "official" : "unofficial"),
                category: "APK Port",
                dev: "APKPorts.com",
                desc: title + " — Android port listed on apkports.com. Open in the In-Theme Browser to view full notes and download APK.",
                cover: cover
            });
        }
        return results;
    }

    function fetchLiveApkPorts() {
        isLoading = true;
        var url = "https://www.apkports.com/games";
        if (activeSection === "fan-games") url = "https://www.apkports.com/fan-games";
        else if (activeSection === "search" && String(searchQuery || "").trim() !== "")
            url = "https://www.apkports.com/games?q=" + encodeURIComponent(String(searchQuery).trim());
        else if (sortMode === "newest" || activeSection === "recent")
            url = "https://www.apkports.com/games?sort=newest";

        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return;
            isLoading = false;
            if (xhr.status >= 200 && xhr.status < 400 && xhr.responseText) {
                var parsed = parseApkPortsHtml(xhr.responseText);
                if (parsed.length > 0) {
                    allGamesCache = parsed;
                    rebuildGrid();
                    return;
                }
            }
            if (allGamesCache.length === 0) {
                allGamesCache = fallbackCatalog.slice(0);
                rebuildGrid();
            }
        };
        xhr.open("GET", url);
        xhr.send();
    }

    function openItemDetail(idx) {
        if (idx < 0 || idx >= pageGridModel.count) return;
        detailGame = pageGridModel.get(idx);
        detailOpen = true;
        selectSfx.play();
    }

    function openDetailInBrowser(slug) {
        var u = "https://www.apkports.com/game/" + encodeURIComponent(String(slug || ""));
        selectSfx.play();
        if (settings.browserMode === "chrome") Qt.openUrlExternally(u);
        else openInThemeBrowser(u);
    }

    function nextPage() {
        if (currentPage + 1 < totalPages()) {
            navSound.play();
            currentPage++;
            selectedIndex = 0;
            rebuildPageSlice();
        }
    }

    function prevPage() {
        if (currentPage > 0) {
            navSound.play();
            currentPage--;
            selectedIndex = 0;
            rebuildPageSlice();
        }
    }

    Component.onCompleted: {
        allGamesCache = fallbackCatalog.slice(0);
        rebuildGrid();
    }

    onVisibleChanged: {
        if (visible) {
            detailOpen = false;
            editingSearch = false;
            fetchLiveApkPorts();
            storeRoot.forceActiveFocus();
        }
    }

    Keys.onLeftPressed: {
        if (detailOpen || editingSearch || pageGridModel.count === 0) return;
        navSound.play();
        selectedIndex = selectedIndex > 0 ? selectedIndex - 1 : pageGridModel.count - 1;
    }
    Keys.onRightPressed: {
        if (detailOpen || editingSearch || pageGridModel.count === 0) return;
        navSound.play();
        selectedIndex = (selectedIndex + 1) % pageGridModel.count;
    }
    Keys.onUpPressed: {
        if (detailOpen || editingSearch || pageGridModel.count === 0) return;
        navSound.play();
        if (selectedIndex >= 3) selectedIndex -= 3;
    }
    Keys.onDownPressed: {
        if (detailOpen || editingSearch || pageGridModel.count === 0) return;
        navSound.play();
        if (selectedIndex + 3 < pageGridModel.count) selectedIndex += 3;
    }
    Keys.onPressed: {
        if (editingSearch) {
            if (api.keys.isCancel(event) && !event.isAutoRepeat) {
                event.accepted = true;
                editingSearch = false;
                storeRoot.forceActiveFocus();
            }
            return;
        }
        if (detailOpen) {
            if (api.keys.isCancel(event) && !event.isAutoRepeat) {
                event.accepted = true;
                backSfx.play();
                detailOpen = false;
            } else if (api.keys.isAccept(event) && !event.isAutoRepeat && detailGame) {
                event.accepted = true;
                openDetailInBrowser(detailGame.slug);
            } else if (api.keys.isDetails(event) && !event.isAutoRepeat && detailGame) {
                event.accepted = true;
                toggleWishlist(detailGame.slug);
            }
            return;
        }
        if (api.keys.isAccept(event) && !event.isAutoRepeat) {
            event.accepted = true;
            openItemDetail(selectedIndex);
        } else if (api.keys.isDetails(event) && !event.isAutoRepeat) {
            event.accepted = true;
            if (selectedIndex >= 0 && selectedIndex < pageGridModel.count) {
                toggleWishlist(pageGridModel.get(selectedIndex).slug);
            }
        } else if (api.keys.isPrevPage(event) && !event.isAutoRepeat) {
            event.accepted = true;
            prevPage();
        } else if (api.keys.isNextPage(event) && !event.isAutoRepeat) {
            event.accepted = true;
            nextPage();
        } else if (api.keys.isCancel(event) && !event.isAutoRepeat) {
            event.accepted = true;
            backSfx.play();
            showHomeScreen();
        }
    }

    // Main Switch 2 Dark eShop Surface
    Rectangle { anchors.fill: parent; color: "#191A1D" }

    // Left Sidebar (#232428) + #E60012 Red eShop Banner
    Rectangle {
        id: leftSidebar
        anchors { top: parent.top; left: parent.left; bottom: eshopFooter.top }
        width: Math.round(parent.width * 0.215)
        color: "#232428"

        Rectangle { anchors { right: parent.right; top: parent.top; bottom: parent.bottom } width: 1; color: "#2D2F36" }

        // Red eShop Top Banner
        Rectangle {
            id: eshopBrandBanner
            anchors { top: parent.top; left: parent.left; right: parent.right }
            height: Math.round(screenheight * 0.095)
            color: "#E60012"

            Row {
                anchors { left: parent.left; leftMargin: vpx(16); verticalCenter: parent.verticalCenter }
                spacing: vpx(10)

                Image {
                    width: vpx(26); height: vpx(26)
                    source: "../assets/images/navigation/ns2_eshop.svg"
                    fillMode: Image.PreserveAspectFit; smooth: true
                    anchors.verticalCenter: parent.verticalCenter
                    layer.enabled: true
                    layer.effect: ColorOverlay { color: "#FFFFFF"; antialiasing: true; cached: true }
                }
                Text {
                    text: "eShop"
                    color: "#FFFFFF"
                    font.family: titleFont.name
                    font.pixelSize: Math.round(screenheight * 0.028)
                    font.bold: true
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
        }

        Flickable {
            anchors { top: eshopBrandBanner.bottom; topMargin: vpx(6); left: parent.left; right: parent.right; bottom: parent.bottom }
            contentHeight: navCol.height + vpx(16)
            clip: true

            Column {
                id: navCol
                width: parent.width
                spacing: vpx(2)

                Repeater {
                    model: storeRoot.sections
                    delegate: Item {
                        width: parent.width
                        height: vpx(40)
                        property bool active: storeRoot.activeSection === modelData.id

                        Rectangle { anchors.fill: parent; color: active ? "#2E3037" : "transparent" }
                        Rectangle {
                            visible: active
                            anchors { left: parent.left; leftMargin: vpx(10); top: parent.top; topMargin: vpx(6); bottom: parent.bottom; bottomMargin: vpx(6) }
                            width: vpx(3.5); radius: vpx(2); color: "#E60012"
                        }
                        Row {
                            anchors { left: parent.left; leftMargin: vpx(22); right: parent.right; rightMargin: vpx(12); verticalCenter: parent.verticalCenter }
                            spacing: vpx(8)
                            Text {
                                text: tr(modelData.label)
                                color: active ? "#FFFFFF" : "#D1D5DB"
                                font.family: titleFont.name
                                font.pixelSize: Math.round(screenheight * 0.022)
                                font.bold: active
                                anchors.verticalCenter: parent.verticalCenter
                            }
                            Text {
                                visible: modelData.id === "wishlist" && storeRoot.wishlistSlugs.length > 0
                                text: "(" + storeRoot.wishlistSlugs.length + ")"
                                color: "#F87171"
                                font.family: titleFont.name
                                font.pixelSize: Math.round(screenheight * 0.018)
                                font.bold: true
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }
                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                navSound.play();
                                storeRoot.detailOpen = false;
                                storeRoot.activeSection = modelData.id;
                                storeRoot.rebuildGrid();
                                if (modelData.id === "fan-games" || modelData.id === "recent") storeRoot.fetchLiveApkPorts();
                            }
                        }
                    }
                }
            }
        }
    }

    // Right Content Area
    Item {
        id: rightPane
        anchors { top: parent.top; left: leftSidebar.right; right: parent.right; bottom: eshopFooter.top }

        // Main 3x2 Grid View
        Item {
            anchors { fill: parent; leftMargin: vpx(26); rightMargin: vpx(26); topMargin: vpx(14); bottomMargin: vpx(10) }
            visible: !storeRoot.detailOpen

            // Top Notice + Active User Avatar
            Item {
                id: eshopTopRow
                anchors { top: parent.top; left: parent.left; right: parent.right }
                height: vpx(46)

                Column {
                    anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                    spacing: vpx(2)
                    Text { text: tr(storeRoot.statusBanner); color: "#D1D5DB"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.019) }
                    Text { text: tr(storeRoot.subBanner); color: "#9CA3AF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.017) }
                }

                // Top-Right User Avatar Button
                Item {
                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                    width: vpx(40); height: vpx(40)
                    Image {
                        id: eshopUserImg
                        anchors.fill: parent
                        source: "../assets/images/avatars/" + (settings.activeCharacter || "mario") + ".png"
                        fillMode: Image.PreserveAspectCrop; visible: false
                    }
                    Rectangle { id: eshopUserMask; anchors.fill: parent; radius: width / 2; visible: false }
                    OpacityMask { anchors.fill: parent; source: eshopUserImg; maskSource: eshopUserMask }
                    Rectangle { anchors.fill: parent; radius: width / 2; color: "transparent"; border.width: vpx(2); border.color: "#4B5563" }
                    MouseArea {
                        anchors.fill: parent
                        onClicked: openUserSelect("Select a user.", null)
                    }
                }
            }

            // Optional Search Input Row
            Rectangle {
                id: eshopSearchBar
                visible: storeRoot.activeSection === "search"
                anchors { top: eshopTopRow.bottom; topMargin: vpx(8); left: parent.left; right: parent.right }
                height: visible ? vpx(36) : 0
                radius: vpx(6); color: "#26282E"; border.width: 1; border.color: storeRoot.editingSearch ? "#E60012" : "#3E424D"

                TextInput {
                    id: eshopSearchInput
                    anchors { left: parent.left; right: searchBtn.left; top: parent.top; bottom: parent.bottom; leftMargin: vpx(12); rightMargin: vpx(8) }
                    verticalAlignment: TextInput.AlignVCenter
                    color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(14)
                    text: storeRoot.searchQuery
                    onActiveFocusChanged: storeRoot.editingSearch = activeFocus
                    onTextChanged: { storeRoot.searchQuery = text; storeRoot.rebuildGrid(); }
                    Keys.onReturnPressed: { storeRoot.editingSearch = false; storeRoot.fetchLiveApkPorts(); storeRoot.forceActiveFocus(); }
                }
                Text {
                    visible: eshopSearchInput.text === ""
                    anchors { left: eshopSearchInput.left; verticalCenter: parent.verticalCenter }
                    text: tr("Search apkports.com library (e.g. GTA, Zelda, Celeste)...")
                    color: "#6B7280"; font.family: titleFont.name; font.pixelSize: vpx(13)
                }
                Rectangle {
                    id: searchBtn
                    anchors { right: parent.right; rightMargin: vpx(4); verticalCenter: parent.verticalCenter }
                    width: vpx(78); height: vpx(28); radius: vpx(4); color: "#E60012"
                    Text { anchors.centerIn: parent; text: tr("Search"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                    MouseArea { anchors.fill: parent; onClicked: { storeRoot.editingSearch = false; storeRoot.fetchLiveApkPorts(); storeRoot.forceActiveFocus(); } }
                }
            }

            // Toolbar Row: Items Count + Filter + Sort Pill
            Item {
                id: eshopToolbar
                anchors { top: eshopSearchBar.bottom; topMargin: vpx(8); left: parent.left; right: parent.right }
                height: vpx(32)

                Text {
                    anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                    text: "Items: " + filteredModel.count + (storeRoot.selectedCategory !== "" ? (" · " + storeRoot.selectedCategory) : "")
                    color: "#E5E7EB"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022)
                }

                Row {
                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                    spacing: vpx(10)

                    Rectangle {
                        width: vpx(76); height: vpx(28); radius: vpx(4)
                        color: storeRoot.showFilters ? "#1E3A5F" : "transparent"
                        border.width: 1; border.color: storeRoot.showFilters ? "#4FD1FF" : "#525866"
                        Text { anchors.centerIn: parent; text: tr("Filter"); color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: vpx(12) }
                        MouseArea { anchors.fill: parent; onClicked: { navSound.play(); storeRoot.showFilters = !storeRoot.showFilters; } }
                    }
                    Rectangle {
                        width: vpx(124); height: vpx(28); radius: vpx(4); color: "#232429"; border.width: 1; border.color: "#525866"
                        Text {
                            anchors.centerIn: parent
                            text: storeRoot.sortMode === "popular" ? tr("Popularity") : (storeRoot.sortMode === "newest" ? tr("Recent") : tr("Title (A-Z)"))
                            color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: vpx(12)
                        }
                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                navSound.play();
                                if (storeRoot.sortMode === "popular") storeRoot.sortMode = "newest";
                                else if (storeRoot.sortMode === "newest") storeRoot.sortMode = "title";
                                else storeRoot.sortMode = "popular";
                                storeRoot.rebuildGrid();
                            }
                        }
                    }
                }
            }

            // Optional Genre Filter Chips
            Row {
                id: filterChipsRow
                visible: storeRoot.showFilters
                anchors { top: eshopToolbar.bottom; topMargin: visible ? vpx(8) : 0; left: parent.left; right: parent.right }
                height: visible ? vpx(28) : 0
                spacing: vpx(6)
                Repeater {
                    model: storeRoot.genreChips
                    delegate: Rectangle {
                        width: chipLbl.implicitWidth + vpx(18); height: vpx(26); radius: vpx(4)
                        color: storeRoot.selectedCategory === modelData.slug ? "#E60012" : "#2A2C32"
                        Text { id: chipLbl; anchors.centerIn: parent; text: modelData.name; color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(11) }
                        MouseArea { anchors.fill: parent; onClicked: { navSound.play(); storeRoot.selectedCategory = modelData.slug; storeRoot.rebuildGrid(); } }
                    }
                }
            }

            // 3x2 Software Cards Grid
            GridView {
                id: eshopGrid
                anchors { top: filterChipsRow.bottom; topMargin: vpx(12); left: parent.left; right: parent.right; bottom: parent.bottom }
                cellWidth: Math.floor(width / 3)
                cellHeight: Math.floor(height / 2)
                clip: true
                interactive: false
                model: pageGridModel

                delegate: Item {
                    width: eshopGrid.cellWidth
                    height: eshopGrid.cellHeight
                    property bool focusedCard: index === storeRoot.selectedIndex
                    property bool wished: storeRoot.isWishlisted(model.slug)

                    Rectangle {
                        anchors { fill: parent; margins: vpx(7) }
                        radius: vpx(4)
                        color: "#26282E"
                        border.width: focusedCard ? vpx(3) : 1
                        border.color: focusedCard ? theme.accent : "#32353E"
                        clip: true

                        // Cover Banner Top
                        Item {
                            id: cardArtBox
                            anchors { top: parent.top; left: parent.left; right: parent.right }
                            height: Math.round(parent.height * 0.72)

                            Rectangle { anchors.fill: parent; color: "#141518" }
                            Image {
                                anchors.fill: parent
                                source: model.cover
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true; smooth: true
                            }
                            Text {
                                visible: model.cover === ""
                                anchors.centerIn: parent; width: parent.width - vpx(16)
                                horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
                                text: model.title; color: "#9CA3AF"; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true
                            }

                            // Top-right Official / Fan-Game badge
                            Rectangle {
                                visible: model.portType === "official" || model.portType === "fan-games"
                                anchors { top: parent.top; right: parent.right; margins: vpx(6) }
                                width: badgeTxt.implicitWidth + vpx(10); height: vpx(18); radius: vpx(2)
                                color: "#1C8AEB"
                                Text { id: badgeTxt; anchors.centerIn: parent; text: model.portType === "official" ? "OFFICIAL" : "FAN GAME"; color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(9); font.bold: true }
                            }

                            // Wishlist Heart
                            Rectangle {
                                visible: wished
                                anchors { top: parent.top; left: parent.left; margins: vpx(6) }
                                width: vpx(22); height: vpx(22); radius: width / 2; color: "#B0000000"
                                Text { anchors.centerIn: parent; text: "♥"; color: "#FB7185"; font.pixelSize: vpx(12) }
                            }

                            // Category badge bottom-right
                            Rectangle {
                                anchors { bottom: parent.bottom; right: parent.right; margins: vpx(6) }
                                width: catTagTxt.implicitWidth + vpx(10); height: vpx(17); radius: vpx(2); color: "#C0000000"
                                Text { id: catTagTxt; anchors.centerIn: parent; text: model.category; color: "#E5E7EB"; font.family: titleFont.name; font.pixelSize: vpx(9) }
                            }
                        }

                        // Bottom Dark Strip (Title + Red Version Tag)
                        Rectangle {
                            anchors { top: cardArtBox.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
                            color: "#202227"

                            Text {
                                anchors { left: parent.left; leftMargin: vpx(10); right: verBadge.left; rightMargin: vpx(8); verticalCenter: parent.verticalCenter }
                                text: model.title; color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: vpx(12); elide: Text.ElideRight
                            }
                            Rectangle {
                                id: verBadge
                                anchors { right: parent.right; rightMargin: vpx(8); verticalCenter: parent.verticalCenter }
                                width: verTxt.implicitWidth + vpx(10); height: vpx(19); radius: vpx(2); color: "#E60012"
                                Text { id: verTxt; anchors.centerIn: parent; text: "v" + String(model.version).replace(/^v/i, ""); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(10); font.bold: true }
                            }
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                storeRoot.selectedIndex = index;
                                storeRoot.openItemDetail(index);
                            }
                        }
                    }
                }
            }
        }

        // In-eShop Port Detail View
        Item {
            anchors { fill: parent; leftMargin: vpx(28); rightMargin: vpx(28); topMargin: vpx(18); bottomMargin: vpx(14) }
            visible: storeRoot.detailOpen && storeRoot.detailGame !== null

            Row {
                id: detailTopBar
                anchors { top: parent.top; left: parent.left }
                spacing: vpx(8)
                Rectangle {
                    width: vpx(190); height: vpx(32); radius: vpx(4); color: "#26282E"; border.width: 1; border.color: "#3F434E"
                    Text { anchors.centerIn: parent; text: "← " + tr("Back to APKPorts Catalog"); color: "#E5E7EB"; font.family: titleFont.name; font.pixelSize: vpx(12) }
                    MouseArea { anchors.fill: parent; onClicked: { backSfx.play(); storeRoot.detailOpen = false; } }
                }
            }

            Row {
                anchors { top: detailTopBar.bottom; topMargin: vpx(18); left: parent.left; right: parent.right; bottom: parent.bottom }
                spacing: vpx(26)

                Rectangle {
                    width: Math.round(parent.width * 0.43); height: Math.round(width * 0.56)
                    radius: vpx(6); color: "#141518"; border.width: 2; border.color: "#4FD1FF"; clip: true
                    Image { anchors.fill: parent; source: storeRoot.detailGame ? storeRoot.detailGame.cover : ""; fillMode: Image.PreserveAspectCrop; smooth: true }
                }

                Column {
                    width: parent.width - Math.round(parent.width * 0.43) - vpx(26)
                    spacing: vpx(12)

                    Row {
                        spacing: vpx(8)
                        Rectangle {
                            width: ptTxt.implicitWidth + vpx(16); height: vpx(22); radius: vpx(4)
                            color: (storeRoot.detailGame && storeRoot.detailGame.portType === "official") ? "#0891B2" : "#E60012"
                            Text { id: ptTxt; anchors.centerIn: parent; text: storeRoot.detailGame ? (storeRoot.detailGame.portType.toUpperCase() + " PORT") : ""; color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(10); font.bold: true }
                        }
                        Rectangle {
                            width: dvTxt.implicitWidth + vpx(14); height: vpx(22); radius: vpx(4); color: "#2D3038"
                            Text { id: dvTxt; anchors.centerIn: parent; text: storeRoot.detailGame ? ("v" + storeRoot.detailGame.version) : ""; color: "#E5E7EB"; font.family: titleFont.name; font.pixelSize: vpx(10) }
                        }
                    }

                    Text {
                        width: parent.width; wrapMode: Text.WordWrap
                        text: storeRoot.detailGame ? storeRoot.detailGame.title : ""
                        color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.036); font.bold: true
                    }

                    Text {
                        width: parent.width; wrapMode: Text.WordWrap
                        text: storeRoot.detailGame ? storeRoot.detailGame.desc : ""
                        color: "#D1D5DB"; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022); lineHeight: 1.35
                    }

                    Row {
                        spacing: vpx(12)
                        Rectangle {
                            width: vpx(230); height: vpx(40); radius: vpx(6); color: "#E60012"
                            Text { anchors.centerIn: parent; text: tr("Open in In-Theme Browser"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: if (storeRoot.detailGame) storeRoot.openDetailInBrowser(storeRoot.detailGame.slug) }
                        }
                        Rectangle {
                            width: vpx(164); height: vpx(40); radius: vpx(6); color: "transparent"; border.width: 1; border.color: "#525866"
                            Text {
                                anchors.centerIn: parent
                                text: (storeRoot.detailGame && storeRoot.isWishlisted(storeRoot.detailGame.slug)) ? tr("In Wish List ♥") : tr("Add to Wish List")
                                color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: vpx(12)
                            }
                            MouseArea { anchors.fill: parent; onClicked: if (storeRoot.detailGame) storeRoot.toggleWishlist(storeRoot.detailGame.slug) }
                        }
                    }
                }
            }
        }
    }

    // Bottom Switch 2 Dark Footer Bar
    Item {
        id: eshopFooter
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: Math.round(screenheight * 0.082)

        Rectangle { anchors.fill: parent; color: "#191A1D" }
        Rectangle { anchors { top: parent.top; left: parent.left; right: parent.right } height: 1; color: "#2D2F36" }

        Row {
            anchors { left: parent.left; leftMargin: vpx(28); verticalCenter: parent.verticalCenter }
            spacing: vpx(16)
            Image {
                width: vpx(36); height: vpx(26)
                source: "../assets/images/navigation/ns2_controller_glyph.svg"
                fillMode: Image.PreserveAspectFit; smooth: true
                anchors.verticalCenter: parent.verticalCenter
                layer.enabled: true
                layer.effect: ColorOverlay { color: "#E5E7EB"; antialiasing: true; cached: true }
            }
            Row {
                visible: !storeRoot.detailOpen
                spacing: vpx(10)
                anchors.verticalCenter: parent.verticalCenter
                Rectangle {
                    width: vpx(48); height: vpx(24); radius: vpx(4); color: storeRoot.currentPage > 0 ? "#2D3038" : "#22242A"
                    Text { anchors.centerIn: parent; text: "L1  ‹"; color: storeRoot.currentPage > 0 ? "#FFFFFF" : "#6B7280"; font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: true }
                    MouseArea { anchors.fill: parent; onClicked: storeRoot.prevPage() }
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Page " + (storeRoot.currentPage + 1) + " / " + storeRoot.totalPages()
                    color: "#D1D5DB"; font.family: titleFont.name; font.pixelSize: vpx(12)
                }
                Rectangle {
                    width: vpx(48); height: vpx(24); radius: vpx(4); color: (storeRoot.currentPage + 1 < storeRoot.totalPages()) ? "#2D3038" : "#22242A"
                    Text { anchors.centerIn: parent; text: "›  R2"; color: (storeRoot.currentPage + 1 < storeRoot.totalPages()) ? "#FFFFFF" : "#6B7280"; font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: true }
                    MouseArea { anchors.fill: parent; onClicked: storeRoot.nextPage() }
                }
            }
        }

        Row {
            anchors { right: parent.right; rightMargin: vpx(28); verticalCenter: parent.verticalCenter }
            spacing: vpx(22)

            Row {
                visible: !storeRoot.detailOpen && pageGridModel.count > 0
                spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: "#FFFFFF"; anchors.verticalCenter: parent.verticalCenter
                    Text { anchors.centerIn: parent; text: "X"; color: "#191A1D"; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                }
                Text { text: tr("Wish List"); color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: vpx(13); anchors.verticalCenter: parent.verticalCenter }
                MouseArea { anchors.fill: parent; onClicked: if (storeRoot.selectedIndex >= 0 && storeRoot.selectedIndex < pageGridModel.count) storeRoot.toggleWishlist(pageGridModel.get(storeRoot.selectedIndex).slug) }
            }
            Row {
                spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: "#FFFFFF"; anchors.verticalCenter: parent.verticalCenter
                    Text { anchors.centerIn: parent; text: "B"; color: "#191A1D"; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                }
                Text { text: tr("Back"); color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: vpx(13); anchors.verticalCenter: parent.verticalCenter }
                MouseArea { anchors.fill: parent; onClicked: { backSfx.play(); if (storeRoot.detailOpen) storeRoot.detailOpen = false; else showHomeScreen(); } }
            }
            Row {
                visible: !storeRoot.detailOpen && pageGridModel.count > 0
                spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: "#FFFFFF"; anchors.verticalCenter: parent.verticalCenter
                    Text { anchors.centerIn: parent; text: "A"; color: "#191A1D"; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                }
                Text { text: tr("Confirm"); color: "#F3F4F6"; font.family: titleFont.name; font.pixelSize: vpx(13); anchors.verticalCenter: parent.verticalCenter }
                MouseArea { anchors.fill: parent; onClicked: storeRoot.openItemDetail(storeRoot.selectedIndex) }
            }
        }
    }
}
