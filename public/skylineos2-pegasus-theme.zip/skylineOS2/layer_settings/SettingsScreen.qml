// skylineOS 2 — SettingsScreen.qml (Switch 2 Split Settings: Profile, Friends, Customize Home, HUD & Colors, User & Browser, About)
import QtQuick 2.12
import QtQuick.Layouts 1.3
import QtGraphicalEffects 1.0

FocusScope {
    id: settingsRoot
    anchors.fill: parent

    property int currentTab: 0
    property bool showMemoryViewer: false
    property bool editingTextField: false
    property string editingKey: ""
    property string editingDraft: ""

    property string activeUserName: (api.memory.has("Username") && api.memory.get("Username") !== "") ? String(api.memory.get("Username")) : "Mario"
    property string activeCharId: api.memory.has("ns2_active_character") ? String(api.memory.get("ns2_active_character")) : "mario"
    property string activeFriendCode: "SW-4821-7094-1122"
    property int refreshTick: 0

    property bool isDarkPage: (settings.appearanceMode === "Dark") || (settings.appearanceMode === "Auto" && settings.darkMode === "Yes")
    property color pageBg: isDarkPage ? "#1A1C21" : "#EFEFEF"
    property color sidebarBg: isDarkPage ? "#22252C" : "#EAEAEA"
    property color cardBg: isDarkPage ? "#2C303A" : "#FFFFFF"
    property color textMain: isDarkPage ? "#F3F4F6" : "#2C2C2C"
    property color textMuted: isDarkPage ? "#9CA3AF" : "#6B7280"
    property color dividerColor: isDarkPage ? "#353944" : "#C8C8C8"

    property var hudSwatches: [
        { id: "Auto", label: "Auto", hex: "#64748B" },
        { id: "Mario Red", label: "Mario Red", hex: "#E60012" },
        { id: "Luigi Green", label: "Luigi Green", hex: "#00A651" },
        { id: "Peach Pink", label: "Peach Pink", hex: "#FF5E99" },
        { id: "Yoshi Green", label: "Yoshi Green", hex: "#65C322" },
        { id: "DK Amber", label: "DK Amber", hex: "#E67E22" },
        { id: "Bowser Gold", label: "Bowser Gold", hex: "#D97706" },
        { id: "Switch Cyan", label: "Switch Cyan", hex: "#10AEBE" }
    ]

    property var sampleFriends: [
        { name: "Luigi", charId: "luigi", online: true, status: "Online · Mario Kart World" },
        { name: "Peach", charId: "peach", online: true, status: "Online · Hollow Knight: Silksong" },
        { name: "Yoshi", charId: "yoshi", online: true, status: "Online · Cuphead" },
        { name: "DK", charId: "dk", online: false, status: "Offline · 2h ago" }
    ]

    property var navTabs: [
        { id: "profile", label: "Profile", sub: "", dividerAfter: true },
        { id: "friends", label: "Friend List", sub: "Online: 3", dividerAfter: false },
        { id: "customize", label: "Customize", sub: "", dividerAfter: false },
        { id: "hud", label: "HUD", sub: "", dividerAfter: true },
        { id: "userSettings", label: "User Settings", sub: "", dividerAfter: false },
        { id: "about", label: "About", sub: "", dividerAfter: false }
    ]

    ListModel { id: playActivityModel }

    // Legacy compatibility list models for MemoryViewer inspection
    ListModel {
        id: legacyCompatModel
        ListElement { settingName: "Username"; setting: "" }
        ListElement { settingName: "UI Sounds"; setting: "" }
        ListElement { settingName: "Game Background"; setting: "" }
        ListElement { settingName: "Background Transparency"; setting: "" }
        ListElement { settingName: "Home Card Size"; setting: "" }
        ListElement { settingName: "Cover Spacing"; setting: "" }
        ListElement { settingName: "Border Gap"; setting: "" }
        ListElement { settingName: "Border Width"; setting: "" }
        ListElement { settingName: "Dock Size Pct"; setting: "" }
        ListElement { settingName: "Max games on Home Screen"; setting: "" }
        ListElement { settingName: "Appearance Polarity"; setting: "" }
        ListElement { settingName: "Dark Mode"; setting: "" }
        ListElement { settingName: "HUD Theme Accent"; setting: "" }
        ListElement { settingName: "Browser Mode"; setting: "" }
        ListElement { settingName: "Browser default link"; setting: "" }
        ListElement { settingName: "Time Format"; setting: "" }
        ListElement { settingName: "Display Battery Percentage"; setting: "" }
        ListElement { settingName: "Display Wifi Icon"; setting: "" }
        ListElement { settingName: "Multi User"; setting: "" }
    }

    function openTab(idx) {
        if (idx >= 0 && idx < navTabs.length) currentTab = idx;
        refreshProfileUi();
    }

    function refreshProfileUi() {
        activeUserName = (api.memory.has("Username") && api.memory.get("Username") !== "") ? String(api.memory.get("Username")) : "Mario";
        activeCharId = api.memory.has("ns2_active_character") ? String(api.memory.get("ns2_active_character")) : "mario";
        refreshPlayActivity();
        refreshTick++;
    }

    function refreshPlayActivity() {
        playActivityModel.clear();
        var items = [];
        for (var i = 0; i < api.allGames.count; i++) {
            var g = api.allGames.get(i);
            var secs = api.memory.has(g.title) ? parseInt(api.memory.get(g.title)) : 0;
            if (isNaN(secs)) secs = 0;
            var hrs = Math.max(1, Math.round(secs / 3600.0));
            var cover = g.assets.boxFront || g.assets.tile || g.assets.screenshots[0] || "";
            items.push({ title: g.title, cover: cover, hours: hrs, rawSecs: secs });
        }
        items.sort(function(a, b) { return b.rawSecs - a.rawSecs; });
        for (var j = 0; j < Math.min(5, items.length); j++) {
            playActivityModel.append(items[j]);
        }
    }

    function setMem(key, val) {
        api.memory.set(key, val);
        refreshSettings();
        refreshProfileUi();
    }

    function cycleValue(key, options, currentVal, dir) {
        var idx = -1;
        for (var i = 0; i < options.length; i++) {
            if (String(options[i]) === String(currentVal)) { idx = i; break; }
        }
        if (idx < 0) idx = 0;
        var nextIdx = (idx + dir + options.length) % options.length;
        setMem(key, String(options[nextIdx]));
        navSound.play();
    }

    function applyHudSwatch(swatch) {
        api.memory.set("HUD Theme Accent", swatch.id);
        if (swatch.id !== "Auto") {
            api.memory.set("Accent Light Mode", swatch.hex);
            api.memory.set("Accent Dark Mode", swatch.hex);
        }
        selectSfx.play();
        refreshSettings();
        refreshTick++;
    }

    function applyPolarity(modeLabel) {
        api.memory.set("Appearance Polarity", modeLabel);
        if (modeLabel === "Dark") api.memory.set("Dark Mode", "Yes");
        else if (modeLabel === "Light") api.memory.set("Dark Mode", "No");
        selectSfx.play();
        refreshSettings();
        refreshTick++;
    }

    function resetCustomizeDefaults() {
        api.memory.set("UI Sounds", "Yes");
        api.memory.set("Game Background", "Screenshot");
        api.memory.set("Background Transparency", "25");
        api.memory.set("Home Card Size", "35");
        api.memory.set("Cover Spacing", "0.140");
        api.memory.set("Border Gap", "7");
        api.memory.set("Border Width", "6");
        api.memory.set("Dock Size Pct", "13.3");
        api.memory.set("Max games on Home Screen", "12");
        api.memory.set("Enable DropShadows", "Yes");
        selectSfx.play();
        refreshSettings();
        refreshTick++;
    }

    function restoreAllSettings() {
        resetCustomizeDefaults();
        api.memory.set("Appearance Polarity", "Auto");
        api.memory.set("Dark Mode", "No");
        api.memory.set("HUD Theme Accent", "Auto");
        api.memory.set("Accent Light Mode", "#10AEBE");
        api.memory.set("Accent Dark Mode", "#1d9bf3");
        api.memory.set("Browser Mode", "in-app");
        api.memory.set("Browser default link", "https://www.nintendo.com");
        api.memory.set("Time Format", "12hr");
        api.memory.set("Display Battery Percentage", "No");
        api.memory.set("Display Wifi Icon", "Yes");
        api.memory.set("Multi User", "No");
        turnOnSfx.play();
        refreshSettings();
        refreshProfileUi();
    }

    function startInlineEdit(key, initialVal) {
        editingKey = key;
        editingDraft = String(initialVal || "");
        editingTextField = true;
        Qt.callLater(function() { inlineInput.forceActiveFocus(); });
    }

    function commitInlineEdit() {
        if (editingKey !== "") {
            var val = String(editingDraft || "").trim();
            if (editingKey === "Username" && val === "") val = "Mario";
            api.memory.set(editingKey, val);
            if (editingKey === "Username") api.memory.set("Launcher User", val);
            refreshSettings();
            refreshProfileUi();
            selectSfx.play();
        }
        editingTextField = false;
        editingKey = "";
        settingsRoot.forceActiveFocus();
    }

    onVisibleChanged: {
        if (visible) {
            showMemoryViewer = false;
            editingTextField = false;
            refreshProfileUi();
            settingsRoot.forceActiveFocus();
        }
    }

    Keys.onUpPressed: {
        if (showMemoryViewer || editingTextField) return;
        navSound.play();
        currentTab = (currentTab - 1 + navTabs.length) % navTabs.length;
    }
    Keys.onDownPressed: {
        if (showMemoryViewer || editingTextField) return;
        navSound.play();
        currentTab = (currentTab + 1) % navTabs.length;
    }
    Keys.onPressed: {
        if (showMemoryViewer || editingTextField) return;
        if (api.keys.isCancel(event) && !event.isAutoRepeat) {
            event.accepted = true;
            backSfx.play();
            showHomeScreen();
        } else if (api.keys.isAccept(event) && !event.isAutoRepeat) {
            event.accepted = true;
            navSound.play();
            currentTab = (currentTab === 0) ? 2 : 0;
        }
    }

    Rectangle { anchors.fill: parent; color: settingsRoot.pageBg }

    // Top Header Row: Avatar + "{User}'s Settings" + Hairline Divider
    Item {
        id: headerBox
        anchors { top: parent.top; left: parent.left; right: parent.right; leftMargin: screenmargin; rightMargin: screenmargin }
        height: Math.round(screenheight * 0.115)

        Row {
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            spacing: vpx(14)

            Item {
                width: Math.round(screenheight * 0.068); height: width; anchors.verticalCenter: parent.verticalCenter
                Image { id: hdrAv; anchors.fill: parent; source: "../assets/images/avatars/" + settingsRoot.activeCharId + ".png"; fillMode: Image.PreserveAspectCrop; visible: false }
                Rectangle { id: hdrMask; anchors.fill: parent; radius: width / 2; visible: false }
                OpacityMask { anchors.fill: parent; source: hdrAv; maskSource: hdrMask }
            }
            Text {
                text: settingsRoot.activeUserName + "\u2019s Settings"
                color: settingsRoot.textMain
                font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.036); font.bold: true
                anchors.verticalCenter: parent.verticalCenter
            }
        }
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: settingsRoot.dividerColor }
    }

    // Main Split Layout (Left 29.5% Sidebar / Right Content Pane)
    Item {
        id: splitBody
        anchors { top: headerBox.bottom; left: parent.left; right: parent.right; bottom: settingsFooter.top }

        Rectangle {
            id: leftSidebar
            anchors { top: parent.top; bottom: parent.bottom; left: parent.left }
            width: Math.round(parent.width * 0.295)
            color: settingsRoot.sidebarBg

            Column {
                anchors { top: parent.top; topMargin: Math.round(screenheight * 0.03); left: parent.left; leftMargin: screenmargin; right: parent.right; rightMargin: vpx(16) }
                spacing: vpx(6)

                Repeater {
                    model: settingsRoot.navTabs
                    delegate: Column {
                        width: parent.width
                        spacing: vpx(8)
                        property bool sel: index === settingsRoot.currentTab

                        Rectangle {
                            width: parent.width
                            height: modelData.sub !== "" ? vpx(56) : vpx(44)
                            color: sel ? settingsRoot.cardBg : "transparent"
                            border.width: sel ? vpx(3) : vpx(3)
                            border.color: sel ? theme.accent : "transparent"

                            Rectangle {
                                visible: sel
                                anchors { left: parent.left; leftMargin: vpx(7); top: parent.top; topMargin: vpx(8); bottom: parent.bottom; bottomMargin: vpx(8) }
                                width: vpx(3.5); color: theme.accent
                            }
                            Column {
                                anchors { left: parent.left; leftMargin: vpx(18); verticalCenter: parent.verticalCenter }
                                spacing: vpx(2)
                                Text { text: tr(modelData.label); color: sel ? theme.accent : settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.026); font.bold: sel }
                                Text { visible: modelData.sub !== ""; text: modelData.sub; color: settingsRoot.textMuted; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.018) }
                            }
                            MouseArea { anchors.fill: parent; onClicked: { navSound.play(); settingsRoot.currentTab = index; } }
                        }

                        Rectangle { visible: modelData.dividerAfter; width: parent.width; height: 1; color: settingsRoot.dividerColor }
                    }
                }
            }
        }

        // Right Content Pane
        Flickable {
            id: rightFlick
            anchors { top: parent.top; bottom: parent.bottom; left: leftSidebar.right; right: parent.right; leftMargin: vpx(34); rightMargin: screenmargin; topMargin: vpx(22); bottomMargin: vpx(14) }
            contentHeight: rightContentCol.height + vpx(24)
            clip: true

            Column {
                id: rightContentCol
                width: parent.width
                spacing: vpx(16)

                // TAB 0: PROFILE
                Column {
                    visible: settingsRoot.currentTab === 0
                    width: parent.width; spacing: vpx(18)

                    Row {
                        width: parent.width; spacing: vpx(24)

                        // Square Profile Portrait
                        Image {
                            width: Math.round(screenheight * 0.245); height: width
                            source: "../assets/images/avatars/" + settingsRoot.activeCharId + ".png"
                            fillMode: Image.PreserveAspectCrop; smooth: true
                        }

                        Column {
                            width: parent.width - Math.round(screenheight * 0.245) - vpx(24)
                            spacing: 0

                            Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                            // Username Row + Edit
                            Item {
                                width: parent.width; height: vpx(46)
                                Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: settingsRoot.activeUserName; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.032) }
                                Rectangle {
                                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                                    width: vpx(72); height: vpx(30); radius: vpx(6); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                                    Text { anchors.centerIn: parent; text: tr("Edit"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12) }
                                    MouseArea { anchors.fill: parent; onClicked: settingsRoot.startInlineEdit("Username", settingsRoot.activeUserName) }
                                }
                            }
                            Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                            // Online Status + Current Game
                            Item {
                                width: parent.width; height: vpx(62)
                                Row {
                                    anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                                    spacing: vpx(12)
                                    Image {
                                        width: vpx(44); height: vpx(44)
                                        source: (api.allGames.count > 0) ? (api.allGames.get(0).assets.boxFront || api.allGames.get(0).assets.tile || "") : ""
                                        fillMode: Image.PreserveAspectCrop; smooth: true
                                    }
                                    Column {
                                        anchors.verticalCenter: parent.verticalCenter; spacing: vpx(2)
                                        Row {
                                            spacing: vpx(6)
                                            Rectangle { width: vpx(9); height: vpx(9); radius: vpx(2); color: "#2ED573"; anchors.verticalCenter: parent.verticalCenter }
                                            Text { text: "Online"; color: "#2ED573"; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                                        }
                                        Text { text: api.allGames.count > 0 ? api.allGames.get(0).title : "SkylineOS 2"; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                                    }
                                }
                            }
                            Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                            Item {
                                width: parent.width; height: vpx(44)
                                Text {
                                    anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                                    text: "Friend Code: " + settingsRoot.activeFriendCode
                                    color: settingsRoot.textMuted; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022)
                                }
                            }
                        }
                    }

                    // Play Activity
                    Column {
                        width: parent.width; spacing: vpx(8)
                        Row {
                            spacing: vpx(8)
                            Rectangle { width: vpx(4); height: vpx(18); color: settingsRoot.textMuted; anchors.verticalCenter: parent.verticalCenter }
                            Text { text: tr("Play Activity"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.026); font.bold: true }
                        }
                        Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                        Repeater {
                            model: playActivityModel
                            delegate: Column {
                                width: parent.width
                                Row {
                                    width: parent.width; height: vpx(54); spacing: vpx(14)
                                    Image { width: vpx(42); height: vpx(42); source: model.cover; fillMode: Image.PreserveAspectCrop; smooth: true; anchors.verticalCenter: parent.verticalCenter }
                                    Column {
                                        anchors.verticalCenter: parent.verticalCenter; spacing: vpx(2)
                                        Text { text: model.title; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.023); font.bold: true }
                                        Text { text: "Played for " + model.hours + " hours or more"; color: theme.accent; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.019) }
                                    }
                                }
                                Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }
                            }
                        }
                    }
                }

                // TAB 1: FRIEND LIST
                Column {
                    visible: settingsRoot.currentTab === 1
                    width: parent.width; spacing: vpx(10)

                    Row {
                        spacing: vpx(8)
                        Rectangle { width: vpx(4); height: vpx(18); color: theme.accent; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: tr("Friend List"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.026); font.bold: true }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    Repeater {
                        model: settingsRoot.sampleFriends
                        delegate: Column {
                            width: parent.width
                            Row {
                                width: parent.width; height: vpx(58); spacing: vpx(14)
                                Image { width: vpx(44); height: vpx(44); source: "../assets/images/avatars/" + modelData.charId + ".png"; fillMode: Image.PreserveAspectCrop; smooth: true; anchors.verticalCenter: parent.verticalCenter }
                                Column {
                                    anchors.verticalCenter: parent.verticalCenter; spacing: vpx(2)
                                    Text { text: modelData.name; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(15); font.bold: true }
                                    Row {
                                        spacing: vpx(6)
                                        Rectangle { width: vpx(8); height: vpx(8); radius: vpx(2); color: modelData.online ? "#2ED573" : "#9CA3AF"; anchors.verticalCenter: parent.verticalCenter }
                                        Text { text: modelData.status; color: modelData.online ? "#2ED573" : settingsRoot.textMuted; font.family: titleFont.name; font.pixelSize: vpx(12) }
                                    }
                                }
                            }
                            Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }
                        }
                    }
                }

                // TAB 2: CUSTOMIZE HOME
                Column {
                    visible: settingsRoot.currentTab === 2
                    width: parent.width; spacing: vpx(4)

                    Item {
                        width: parent.width; height: vpx(36)
                        Row {
                            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                            spacing: vpx(8)
                            Rectangle { width: vpx(4); height: vpx(18); color: theme.accent; anchors.verticalCenter: parent.verticalCenter }
                            Text { text: tr("Customize Home"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.026); font.bold: true }
                        }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(96); height: vpx(28); radius: vpx(14); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                            Text { anchors.centerIn: parent; text: tr("Reset"); color: theme.accent; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: settingsRoot.resetCustomizeDefaults() }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Toggle: UI Sounds
                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("UI Sounds"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(78); height: vpx(30); radius: height / 2
                            color: settings.uiSoundsEnabled === "Yes" ? theme.accent : settingsRoot.sidebarBg
                            Text { anchors.centerIn: parent; text: settings.uiSoundsEnabled === "Yes" ? "ON" : "OFF"; color: settings.uiSoundsEnabled === "Yes" ? "#FFFFFF" : settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: settingsRoot.setMem("UI Sounds", settings.uiSoundsEnabled === "Yes" ? "No" : "Yes") }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Toggle: Game Background
                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Game Background"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(124); height: vpx(30); radius: height / 2
                            color: settings.gameBackground !== "No" ? theme.accent : settingsRoot.sidebarBg
                            Text { anchors.centerIn: parent; text: settings.gameBackground; color: settings.gameBackground !== "No" ? "#FFFFFF" : settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: settingsRoot.cycleValue("Game Background", ["Screenshot", "Fanart", "Boxart", "No"], settings.gameBackground, 1) }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Stepper rows
                    Repeater {
                        model: [
                            { label: "Background Transparency (%)", key: "Background Transparency", val: settings.bgTransparency, opts: ["0","10","20","25","30","40","50","60","70","80","90"] },
                            { label: "Home Card Size (%)", key: "Home Card Size", val: settings.homeCardSize, opts: ["28","30","32","34","35","36","38","40","42"] },
                            { label: "Cover Spacing", key: "Cover Spacing", val: String(settings.cardSpacingRatio), opts: ["0.090","0.115","0.140","0.165","0.190","0.220"] },
                            { label: "Border Gap (px @720p)", key: "Border Gap", val: String(settings.borderGap720), opts: ["4","5","6","7","8","9","10","12"] },
                            { label: "Border Width (px @720p)", key: "Border Width", val: String(settings.borderThick720), opts: ["4","5","6","7","8","9","10"] },
                            { label: "Dock Size Pct (%)", key: "Dock Size Pct", val: String(settings.dockHeightPct), opts: ["10.0","11.5","13.3","14.5","16.0"] },
                            { label: "Max Games on Home", key: "Max games on Home Screen", val: String(settings.softCount), opts: ["8","10","12","16","20","25"] }
                        ]
                        delegate: Column {
                            width: parent.width
                            Item {
                                width: parent.width; height: vpx(46)
                                Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr(modelData.label); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                                Row {
                                    anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                                    spacing: vpx(10)
                                    Rectangle {
                                        width: vpx(32); height: vpx(28); radius: vpx(6); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                                        Text { anchors.centerIn: parent; text: "-"; color: settingsRoot.textMain; font.bold: true }
                                        MouseArea { anchors.fill: parent; onClicked: settingsRoot.cycleValue(modelData.key, modelData.opts, modelData.val, -1) }
                                    }
                                    Text { width: vpx(58); horizontalAlignment: Text.AlignHCenter; anchors.verticalCenter: parent.verticalCenter; text: modelData.val; color: theme.accent; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                                    Rectangle {
                                        width: vpx(32); height: vpx(28); radius: vpx(6); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                                        Text { anchors.centerIn: parent; text: "+"; color: settingsRoot.textMain; font.bold: true }
                                        MouseArea { anchors.fill: parent; onClicked: settingsRoot.cycleValue(modelData.key, modelData.opts, modelData.val, 1) }
                                    }
                                }
                            }
                            Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }
                        }
                    }
                }

                // TAB 3: HUD & COLORS (4x2 Circular Swatch Grid + Appearance Polarity)
                Column {
                    visible: settingsRoot.currentTab === 3
                    width: parent.width; spacing: vpx(14)

                    Row {
                        spacing: vpx(8)
                        Rectangle { width: vpx(4); height: vpx(18); color: theme.accent; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: tr("HUD & Colors"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.026); font.bold: true }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    Text { text: tr("Theme Accent Color"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14); font.bold: true }

                    Grid {
                        width: parent.width
                        columns: 4
                        rowSpacing: vpx(18)
                        columnSpacing: vpx(14)

                        Repeater {
                            model: settingsRoot.hudSwatches
                            delegate: Item {
                                width: Math.floor((parent.width - vpx(42)) / 4)
                                height: vpx(78)
                                property bool selected: settings.hudThemeId === modelData.id

                                Column {
                                    anchors.centerIn: parent; spacing: vpx(6)
                                    Rectangle {
                                        width: vpx(48); height: vpx(48); radius: width / 2
                                        anchors.horizontalCenter: parent.horizontalCenter
                                        color: modelData.hex
                                        border.width: selected ? vpx(3) : 0
                                        border.color: settingsRoot.textMain
                                        Text { visible: selected; anchors.centerIn: parent; text: "✓"; color: "#FFFFFF"; font.pixelSize: vpx(18); font.bold: true }
                                    }
                                    Text {
                                        anchors.horizontalCenter: parent.horizontalCenter
                                        text: modelData.label
                                        color: selected ? settingsRoot.textMain : settingsRoot.textMuted
                                        font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: selected
                                    }
                                }
                                MouseArea { anchors.fill: parent; onClicked: settingsRoot.applyHudSwatch(modelData) }
                            }
                        }
                    }

                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Appearance Polarity"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Row {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            spacing: vpx(8)
                            Repeater {
                                model: ["Auto", "Light", "Dark"]
                                delegate: Rectangle {
                                    property bool active: settings.appearanceMode === modelData
                                    width: vpx(74); height: vpx(30); radius: height / 2
                                    color: active ? theme.accent : settingsRoot.sidebarBg
                                    Text { anchors.centerIn: parent; text: modelData; color: active ? "#FFFFFF" : settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: active }
                                    MouseArea { anchors.fill: parent; onClicked: settingsRoot.applyPolarity(modelData) }
                                }
                            }
                        }
                    }
                }

                // TAB 4: USER & BROWSER SETTINGS
                Column {
                    visible: settingsRoot.currentTab === 4
                    width: parent.width; spacing: vpx(2)

                    Row {
                        height: vpx(36); spacing: vpx(8)
                        Rectangle { width: vpx(4); height: vpx(18); color: theme.accent; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: tr("User & Browser"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.026); font.bold: true; anchors.verticalCenter: parent.verticalCenter }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Active User Profile Switcher
                    Item {
                        width: parent.width; height: vpx(48)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Active User Profile"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(186); height: vpx(32); radius: vpx(8); color: theme.accent
                            Text { anchors.centerIn: parent; text: tr("Switch or Add (+) User"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: openUserSelect("Select a user.", function() { settingsRoot.refreshProfileUi(); }) }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Ask User on Play
                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Ask User on Play"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(82); height: vpx(30); radius: height / 2
                            color: settings.multiUser === "Yes" ? theme.accent : settingsRoot.sidebarBg
                            Text { anchors.centerIn: parent; text: settings.multiUser === "Yes" ? "ON" : "OFF"; color: settings.multiUser === "Yes" ? "#FFFFFF" : settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: settingsRoot.setMem("Multi User", settings.multiUser === "Yes" ? "No" : "Yes") }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Internet Browser Mode
                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Internet Browser Mode"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Row {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            spacing: vpx(8)
                            Rectangle {
                                width: vpx(118); height: vpx(30); radius: vpx(8)
                                color: settings.browserMode === "in-app" ? theme.accent : settingsRoot.sidebarBg
                                Text { anchors.centerIn: parent; text: "In-App Browser"; color: settings.browserMode === "in-app" ? "#FFFFFF" : settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: true }
                                MouseArea { anchors.fill: parent; onClicked: settingsRoot.setMem("Browser Mode", "in-app") }
                            }
                            Rectangle {
                                width: vpx(118); height: vpx(30); radius: vpx(8)
                                color: settings.browserMode === "chrome" ? theme.accent : settingsRoot.sidebarBg
                                Text { anchors.centerIn: parent; text: "Open in Chrome"; color: settings.browserMode === "chrome" ? "#FFFFFF" : settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: true }
                                MouseArea { anchors.fill: parent; onClicked: settingsRoot.setMem("Browser Mode", "chrome") }
                            }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Browser Homepage URL
                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Browser Default URL"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(210); height: vpx(30); radius: vpx(8); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                            Text { anchors { fill: parent; leftMargin: vpx(10); rightMargin: vpx(10); verticalCenter: parent.verticalCenter } verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight; text: settings.browserLink; color: settingsRoot.textMuted; font.family: titleFont.name; font.pixelSize: vpx(11) }
                            MouseArea { anchors.fill: parent; onClicked: settingsRoot.startInlineEdit("Browser default link", settings.browserLink) }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Time Format + Battery % + Wi-Fi
                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Clock Format"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(90); height: vpx(30); radius: vpx(8); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                            Text { anchors.centerIn: parent; text: settings.timeFormat.toUpperCase(); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: settingsRoot.setMem("Time Format", settings.timeFormat === "12hr" ? "24hr" : "12hr") }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Battery Percentage"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(90); height: vpx(30); radius: vpx(8); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                            Text { anchors.centerIn: parent; text: settings.batteryPercentSetting === "Yes" ? "Shown" : "Hidden"; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: settingsRoot.setMem("Display Battery Percentage", settings.batteryPercentSetting === "Yes" ? "No" : "Yes") }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    Item {
                        width: parent.width; height: vpx(46)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Display Wi-Fi Icon"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Rectangle {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            width: vpx(90); height: vpx(30); radius: vpx(8); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                            Text { anchors.centerIn: parent; text: settings.showWifi === "Yes" ? "Shown" : "Hidden"; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                            MouseArea { anchors.fill: parent; onClicked: settingsRoot.setMem("Display Wifi Icon", settings.showWifi === "Yes" ? "No" : "Yes") }
                        }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    // Memory Viewer & Reset
                    Item {
                        width: parent.width; height: vpx(48)
                        Text { anchors { left: parent.left; verticalCenter: parent.verticalCenter } text: tr("Pegasus Memory & Defaults"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14) }
                        Row {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            spacing: vpx(10)
                            Rectangle {
                                width: vpx(126); height: vpx(30); radius: vpx(8); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                                Text { anchors.centerIn: parent; text: tr("Memory Viewer"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: true }
                                MouseArea { anchors.fill: parent; onClicked: { settingsRoot.showMemoryViewer = true; memoryViewerModal.open(); } }
                            }
                            Rectangle {
                                width: vpx(110); height: vpx(30); radius: vpx(8); color: "#DC2626"
                                Text { anchors.centerIn: parent; text: tr("Reset All"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(11); font.bold: true }
                                MouseArea { anchors.fill: parent; onClicked: settingsRoot.restoreAllSettings() }
                            }
                        }
                    }
                }

                // TAB 5: ABOUT (Unbranded)
                Column {
                    visible: settingsRoot.currentTab === 5
                    width: parent.width; spacing: vpx(14)

                    Row {
                        spacing: vpx(8)
                        Rectangle { width: vpx(4); height: vpx(18); color: theme.accent; anchors.verticalCenter: parent.verticalCenter }
                        Text { text: tr("About SkylineOS 2"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.026); font.bold: true }
                    }
                    Rectangle { width: parent.width; height: 1; color: settingsRoot.dividerColor }

                    Text { text: "Designed by Chen.Paradise"; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(15) }
                    Text {
                        text: "Forked from https://github.com/RBertoCases/skylineOS"
                        color: theme.accent; font.family: titleFont.name; font.pixelSize: vpx(14)
                        MouseArea { anchors.fill: parent; onClicked: openInThemeBrowser("https://github.com/RBertoCases/skylineOS") }
                    }
                    Text { text: "2026 For Education purposes Only."; color: settingsRoot.textMuted; font.family: titleFont.name; font.pixelSize: vpx(14) }
                    Text { text: "Hecho con \u2764 en Santurce, PR"; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(15) }
                }
            }
        }
    }

    // Inline Text Editor Popup
    Rectangle {
        visible: settingsRoot.editingTextField
        anchors.fill: parent; z: 120; color: "#88000000"
        Rectangle {
            anchors.centerIn: parent; width: vpx(460); height: vpx(164); radius: vpx(12); color: settingsRoot.cardBg; border.width: vpx(2); border.color: theme.accent
            Column {
                anchors { fill: parent; margins: vpx(20) }
                spacing: vpx(12)
                Text { text: tr("Edit ") + settingsRoot.editingKey; color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(15); font.bold: true }
                Rectangle {
                    width: parent.width; height: vpx(38); radius: vpx(6); color: settingsRoot.sidebarBg; border.width: 1; border.color: settingsRoot.dividerColor
                    TextInput {
                        id: inlineInput
                        anchors { fill: parent; leftMargin: vpx(10); rightMargin: vpx(10) }
                        verticalAlignment: TextInput.AlignVCenter
                        color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(14)
                        text: settingsRoot.editingDraft
                        onTextChanged: settingsRoot.editingDraft = text
                        Keys.onReturnPressed: settingsRoot.commitInlineEdit()
                    }
                }
                Row {
                    anchors.right: parent.right; spacing: vpx(10)
                    Rectangle {
                        width: vpx(88); height: vpx(32); radius: vpx(6); color: settingsRoot.sidebarBg
                        Text { anchors.centerIn: parent; text: tr("Cancel"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: vpx(12) }
                        MouseArea { anchors.fill: parent; onClicked: { settingsRoot.editingTextField = false; settingsRoot.forceActiveFocus(); } }
                    }
                    Rectangle {
                        width: vpx(88); height: vpx(32); radius: vpx(6); color: theme.accent
                        Text { anchors.centerIn: parent; text: tr("Save"); color: "#FFFFFF"; font.family: titleFont.name; font.pixelSize: vpx(12); font.bold: true }
                        MouseArea { anchors.fill: parent; onClicked: settingsRoot.commitInlineEdit() }
                    }
                }
            }
        }
    }

    // Embedded Memory Viewer
    MemoryViewer {
        id: memoryViewerModal
        models: [legacyCompatModel]
        visible: settingsRoot.showMemoryViewer
        onClosed: {
            settingsRoot.showMemoryViewer = false;
            settingsRoot.forceActiveFocus();
        }
    }

    // Bottom Sticky Switch 2 Footer Bar
    Item {
        id: settingsFooter
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: screenmargin; rightMargin: screenmargin }
        height: Math.round(screenheight * 0.088)
        Rectangle { anchors.top: parent.top; width: parent.width; height: 1; color: settingsRoot.dividerColor }

        Image {
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            width: vpx(36); height: vpx(26)
            source: "../assets/images/navigation/ns2_controller_glyph.svg"
            fillMode: Image.PreserveAspectFit; smooth: true
            layer.enabled: true; layer.effect: ColorOverlay { color: settingsRoot.textMain; antialiasing: true; cached: true }
        }

        Row {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            spacing: vpx(24)

            Row {
                spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: settingsRoot.textMain; anchors.verticalCenter: parent.verticalCenter
                    Text { anchors.centerIn: parent; text: "B"; color: settingsRoot.pageBg; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                }
                Text { text: tr("Back"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022); anchors.verticalCenter: parent.verticalCenter }
                MouseArea { anchors.fill: parent; onClicked: { backSfx.play(); showHomeScreen(); } }
            }

            Row {
                spacing: vpx(8); anchors.verticalCenter: parent.verticalCenter
                Rectangle { width: vpx(24); height: vpx(24); radius: width / 2; color: settingsRoot.textMain; anchors.verticalCenter: parent.verticalCenter
                    Text { anchors.centerIn: parent; text: "A"; color: settingsRoot.pageBg; font.family: titleFont.name; font.pixelSize: vpx(13); font.bold: true }
                }
                Text { text: tr("OK"); color: settingsRoot.textMain; font.family: titleFont.name; font.pixelSize: Math.round(screenheight * 0.022); anchors.verticalCenter: parent.verticalCenter }
                MouseArea { anchors.fill: parent; onClicked: { navSound.play(); settingsRoot.currentTab = (settingsRoot.currentTab === 0) ? 2 : 0; } }
            }
        }
    }
}
