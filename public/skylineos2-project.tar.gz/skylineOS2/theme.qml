// skylineOS v2
// Se un giorno mi leggerai, sappi che ti amo, Molly. Addio 24/05/2012 - 04/09/2026

import QtQuick 2.12
import QtQuick.Layouts 1.11
import SortFilterProxyModel 0.2
import QtMultimedia 5.9
import QtGraphicalEffects 1.12
import "qrc:/qmlutils" as PegasusUtils
import "utils.js" as Utils
import "translations.js" as Tr
import "layer_home"
import "layer_grid"
import "layer_settings"
import "layer_help"
import "layer_buttons"
import "layer_detail"
import "Lists"
import "layer_2ds"
import "resources" as Resources

FocusScope {
    id: root


    // Single-launch debounce lock to prevent duplicate am start intents in Pegasus
    property bool isLaunching: false
    Timer {
        id: launchDebounceTimer
        interval: 3500
        repeat: false
        onTriggered: {
            root.isLaunching = false;
        }
    }
    // Load settings
    property var settings: {
        return {
            gameBackground: api.memory.has("Game Background") ? api.memory.get("Game Background") : "Screenshot",
            timeFormat: api.memory.has("Time Format") ? api.memory.get("Time Format") : "12hr",
            wordWrap: api.memory.has("Word Wrap on Titles") ? api.memory.get("Word Wrap on Titles") : "Yes",
            batteryPercentSetting: api.memory.has("Display Battery Percentage") ? api.memory.get("Display Battery Percentage") : "No",
            enableDropShadows: api.memory.has("Enable DropShadows") ? api.memory.get("Enable DropShadows") : "Yes",
            showWifi: api.memory.has("Display Wifi Icon") ? api.memory.get("Display Wifi Icon") : "Yes",
            username: api.memory.has("Username") ? api.memory.get("Username") : "",
            darkMode: api.memory.has("Dark Mode") ? api.memory.get("Dark Mode") : "No",
            homeCardSize: api.memory.has("Home Card Size") ? api.memory.get("Home Card Size") : "35",
            softCount: api.memory.has("Max games on Home Screen") ? parseInt(api.memory.get("Max games on Home Screen")) : 12,
            playBGM: api.memory.has("Background Music") ? api.memory.get("Background Music") : "No",
            showFeed: api.memory.has("Feed Button Show") ? api.memory.get("Feed Button Show") : "Yes",
            showStore: api.memory.has("Store Button Show") ? api.memory.get("Store Button Show") : "Yes",
            showGallery: api.memory.has("Gallery Button Show") ? api.memory.get("Gallery Button Show") : "Yes",
            showController: api.memory.has("Controller Button Show") ? api.memory.get("Controller Button Show") : "Yes",
            showSettings: api.memory.has("Settings Button Show") ? api.memory.get("Settings Button Show") : "Yes",
            showSuspend: api.memory.has("Suspend Button Show") ? api.memory.get("Suspend Button Show") : "Yes",
            bgTransparency: api.memory.has("Background Transparency") ? api.memory.get("Background Transparency") : "25",
            steamGridDBAPIKey: api.memory.has("SteamGridDB API Key") ? api.memory.get("SteamGridDB API Key") : "",
            RAWGKey: api.memory.has("RAWG API Key") ? api.memory.get("RAWG API Key") : "",
            multiUser: api.memory.has("Multi User") ? api.memory.get("Multi User") : "No",
            exophaseID: api.memory.has("Exophase User ID") ? api.memory.get("Exophase User ID") : ""
        };
    }

    // number of games that appear on the homescreen, not including the All Software button
    property int softCount: settings.softCount

    //Hidden apps
    property var hiddenApps: api.memory.has("HiddenApps") ? api.memory.get("HiddenApps") : []

    ListLastPlayed {
        id: listRecent
        max: softCount
    }
    ListLastPlayed {
        id: listByLastPlayed
    }
    ListMostPlayed {
        id: listByMostPlayed
    }
    ListPublisher {
        id: listByPublisher
    }
    ListFavorites {
        id: listFavorites
    }
    ListAllGames {
        id: listByTitle
    }
    Resources.Music {
        id: music
    }

    property int currentCollection: api.memory.has('Last Collection') ? api.memory.get('Last Collection') : -1
    property int nextCollection: api.memory.has('Last Collection') ? api.memory.get('Last Collection') : -1
    property var currentGame
    property bool gameDetailOpen: false
    property real detailOriginX: 0
    property real detailOriginY: 0
    property real detailOriginWidth: 100
    property real detailOriginHeight: 100
    property var softwareList: [listByLastPlayed, listByMostPlayed, listByTitle, listByPublisher, listFavorites]
    property int sortByIndex: api.memory.has('sortIndex') ? api.memory.get('sortIndex') : 0
    property string searchtext
    property string softwareSearch: ""
    property bool wordWrap: (settings.wordWrap === "Yes") ? true : false
    property bool showPercent: (settings.batteryPercentSetting === "Yes") ? true : false
    property bool enableDropShadows: (settings.enableDropShadows === "Yes") ? true : false
    property bool playBGM: (settings.playBGM === "Yes") ? true : false
    property bool multiUserEnabled: (settings.multiUser === "Yes") ? true : false

    property string language: api.memory.has("Language") ? api.memory.get("Language") : "en"

    function tr(text, arg) {
        return Tr.translate(language, text, arg);
    }

    onNextCollectionChanged: {
        changeCollection();
    }

    function changeCollection() {
        if (nextCollection != currentCollection) {
            currentCollection = nextCollection;
            searchtext = "";
            //gameGrid.currentIndex = 0;
        }
    }

    property int collectionIndex: 0
    property int currentGameIndex: 0
    property int screenmargin: vpx(30)
    property real screenwidth: width
    property real screenheight: height
    property bool widescreen: ((height / width) < 0.7)
    property real helpbarheight: Math.round(screenheight * 0.1041) // Calculated manually based on mockup
    property bool darkThemeActive

    function refreshSettings() {
        language = api.memory.has("Language") ? api.memory.get("Language") : "en";
        settings = {
            gameBackground: api.memory.has("Game Background") ? api.memory.get("Game Background") : "Screenshot",
            timeFormat: api.memory.has("Time Format") ? api.memory.get("Time Format") : "12hr",
            wordWrap: api.memory.has("Word Wrap on Titles") ? api.memory.get("Word Wrap on Titles") : "Yes",
            batteryPercentSetting: api.memory.has("Display Battery Percentage") ? api.memory.get("Display Battery Percentage") : "No",
            enableDropShadows: api.memory.has("Enable DropShadows") ? api.memory.get("Enable DropShadows") : "Yes",
            playBGM: api.memory.has("Background Music") ? api.memory.get("Background Music") : "No",
            showWifi: api.memory.has("Display Wifi Icon") ? api.memory.get("Display Wifi Icon") : "No",
            homeCardSize: api.memory.has("Home Card Size") ? api.memory.get("Home Card Size") : "35",
            softCount: api.memory.has("Max games on Home Screen") ? parseInt(api.memory.get("Max games on Home Screen")) : 12,
            steamGridDBAPIKey: api.memory.has("SteamGridDB API Key") ? api.memory.get("SteamGridDB API Key") : "",
            RAWGKey: api.memory.has("RAWG API Key") ? api.memory.get("RAWG API Key") : "",
            bgTransparency: api.memory.has("Background Transparency") ? api.memory.get("Background Transparency") : "25",
            exophaseID: api.memory.has("Exophase User ID") ? api.memory.get("Exophase User ID") : "",
            multiUser: api.memory.has("Multi User") ? api.memory.get("Multi User") : "No",
        };
    }

    function showSoftwareScreen() {
        /*homeScreen.visible = false;
        softwareScreen.visible = true;*/
        refreshSettings();
        softwareScreen.focus = true;
        allSoftSfx.play();
    }

    function showSettingsScreen() {
        settingsScreen.focus = true;
        settingsSfx.play();
    }

    function showSatelliteProfileScreen(n) {
        settingsSfx.play();
        satelliteProfileScreen.open(n);
    }

    function showNewProfileScreen() {
        newUserSfx.play();
        newProfileScreen.open();
    }

    function showButtonScreen(menu) {
        switch (menu) {
        case "info":
            infoScreen.focus = true;
            feedSfx.play();
            break;
        case "backlog":
            backlogScreen.focus = true;
            backlogSfx.play();
            break;
        case "suspend":
            suspendScreen.focus = true;
            standbySfx.play();
            break;
        default:
            break;
        }
    }

    function openGameDetail(originItem, game) {
        if (!originItem || !game)
            return;
        var pos = originItem.mapToItem(root, 0, 0);
        detailOriginX = pos.x;
        detailOriginY = pos.y;
        detailOriginWidth = originItem.width;
        detailOriginHeight = originItem.height;
        currentGame = game;
        gameDetailOpen = true;
        gameDetailScreen.forceActiveFocus();
        gameDetailScreen.currentGame = currentGame;
        detailSfx.play();
    }

    function closeGameDetail() {
        gameDetailOpen = false;
        backSfx.play();
        homeScreen.focus = true;
    }

    function showHomeScreen() {
        refreshSettings();
        softwareSearch = "";
        homeScreen.focus = true;
        currentCollection = -1;
        homeSfx.play();
    }

    function playGame() {
        requestProfile(function () {
            root.state = "playgame";
            launchSfx.play();
            if (currentGame)
                launchGame(currentGame);
        });
    }

    function playSoftware() {
        requestProfile(function () {
            root.state = "playsoftware";
            launchSfx.play();
            if (currentGame)
                launchGame(currentGame);
        });
    }

    function pushToStackTimer(game) {
        if (game != null) {
            api.memory.set("STACK_TIMER", [game.title, Math.floor(Date.now() / 1000)]);
            api.memory.set("LAST_STACK_ITEM", game.title);
        }
    }

    function popToStackTimer() {
        if (api.memory.has("LAST_STACK_ITEM")) {
            var last = api.memory.get("LAST_STACK_ITEM");
            var startTime = api.memory.get("STACK_TIMER")[1];
            var elapsed = Math.floor(Date.now() / 1000) - startTime;

            var prevTime = api.memory.has(last) ? parseInt(api.memory.get(last)) : 0;
            api.memory.set(last, prevTime + elapsed);
        }

        api.memory.unset("LAST_STACK_ITEM");
        api.memory.unset("STACK_TIMER");
    }

    function toggleHideApp(title) {
        var list = hiddenApps;
        var idx = list.indexOf(title);
        if (idx >= 0)
            list.splice(idx, 1);
        else
            list.push(title);

        api.memory.set("HiddenApps", list);
        hiddenApps = list;
    }

    function isAppHidden(title) {
        return typeof (hiddenApps.find(i => i.includes(title))) != "undefined";
    }

    //Hide Popup
    Rectangle {
        id: hideConfirmPopup
        visible: false
        opacity: visible ? 1 : 0
        Behavior on opacity {
            NumberAnimation {
                duration: 150
            }
        }
        property string pendingTitle: ""
        property bool isReverse: false
        property var confirmAction: null
        property var returnFocusItem: null
        property string customTitle: ""
        property string customSubtitle: ""

        anchors.centerIn: parent
        z: 200

        width: vpx(420)
        height: vpx(200)
        radius: vpx(24)
        color: theme.button

        layer.enabled: true
        layer.effect: DropShadow {
            transparentBorder: true
            horizontalOffset: 0
            verticalOffset: vpx(6)
            radius: 20
            samples: 32
            color: "#60000000"
        }

        Column {
            anchors.centerIn: parent
            spacing: vpx(20)

            Text {
                text: hideConfirmPopup.customTitle !== "" ? hideConfirmPopup.customTitle : (hideConfirmPopup.isReverse ? tr("Show \"%1\" again?", hideConfirmPopup.pendingTitle) : tr("Hide \"%1\"?", hideConfirmPopup.pendingTitle))
                width: vpx(380)
                wrapMode: Text.WordWrap
                color: theme.text
                font.family: titleFont.name
                font.pixelSize: Math.round(screenheight * 0.028)
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
                anchors.horizontalCenter: parent.horizontalCenter
            }

            Text {
                text: hideConfirmPopup.customSubtitle !== "" ? hideConfirmPopup.customSubtitle : (hideConfirmPopup.isReverse ? "It will appear on the home screen again" : "It won't appear on the home screen anymore")
                width: vpx(380)
                wrapMode: Text.WordWrap
                color: theme.icon
                font.family: titleFont.name
                font.pixelSize: Math.round(screenheight * 0.020)
                horizontalAlignment: Text.AlignHCenter
                anchors.horizontalCenter: parent.horizontalCenter
            }

            Row {
                spacing: vpx(16)
                anchors.horizontalCenter: parent.horizontalCenter

                Rectangle {
                    width: vpx(130)
                    height: vpx(44)
                    radius: height / 2
                    color: theme.main
                    Text {
                        text: tr("Cancel  B")
                        color: theme.text
                        font.family: titleFont.name
                        font.pixelSize: Math.round(screenheight * 0.022)
                        anchors.centerIn: parent
                    }
                }

                Rectangle {
                    width: vpx(130)
                    height: vpx(44)
                    radius: height / 2
                    color: theme.accent
                    Text {
                        text: tr("A  Confirm")
                        color: "white"
                        font.family: titleFont.name
                        font.pixelSize: Math.round(screenheight * 0.022)
                        anchors.centerIn: parent
                    }
                }
            }
        }

        Keys.onPressed: {
            if (confirmAction) {
                event.accepted = true;
                if (api.keys.isAccept(event) && !event.isAutoRepeat) {
                    var act = confirmAction;
                    var target = returnFocusItem;
                    confirmAction = null;
                    returnFocusItem = null;
                    customTitle = "";
                    customSubtitle = "";
                    hideConfirmPopup.visible = false;
                    turnOffSfx.play();
                    act();
                    if (target)
                        target.forceActiveFocus();
                } else if (api.keys.isCancel(event) && !event.isAutoRepeat) {
                    var back = returnFocusItem;
                    confirmAction = null;
                    returnFocusItem = null;
                    customTitle = "";
                    customSubtitle = "";
                    backSfx.play();
                    hideConfirmPopup.visible = false;
                    if (back)
                        back.forceActiveFocus();
                }
                return;
            }
            if (api.keys.isAccept(event) && !event.isAutoRepeat) {
                event.accepted = true;
                toggleHideApp(pendingTitle);
                hideConfirmPopup.isReverse ? turnOnSfx.play() : turnOffSfx.play();
                hideConfirmPopup.visible = false;
                pendingTitle = "";
                if (softwareScreen.visible) {
                    softwareScreen.focus = true;
                } else {
                    homeScreen.focus = true;
                }
                if (api.memory.get("Show Hidden Apps") === "No")
                    softCount--;
            }
            if (api.keys.isCancel(event)) {
                event.accepted = true;
                backSfx.play();
                hideConfirmPopup.visible = false;
                pendingTitle = "";
                if (softwareScreen.visible)
                    softwareScreen.focus = true;
                else
                    homeScreen.focus = true;
            }
        }
    }

    function requestConfirm(title, subtitle, action, focusItem) {
        hideConfirmPopup.customTitle = title;
        hideConfirmPopup.customSubtitle = subtitle;
        hideConfirmPopup.confirmAction = action;
        hideConfirmPopup.returnFocusItem = focusItem;
        hideConfirmPopup.visible = true;
        hideConfirmPopup.forceActiveFocus();
    }

    function requestHideApp(title) {
        hideConfirmPopup.confirmAction = null;
        hideConfirmPopup.customTitle = "";
        hideConfirmPopup.customSubtitle = "";
        hideConfirmPopup.pendingTitle = title;
        hideConfirmPopup.isReverse = isAppHidden(title) && api.memory.get("Show Hidden Apps") === "Yes";
        hideConfirmPopup.visible = true;
        hideConfirmPopup.forceActiveFocus();
    }

    function registerLauncherUser() {
        api.memory.set("Launcher User", pendingLauncherUser !== "" ? pendingLauncherUser : currentUsername());
    }

    function currentUsername() {
        if (api.memory.get("RA_LoggedIn") === "Yes")
            return api.memory.get("RA_Username") || "";
        if (api.memory.has("Username") && api.memory.get("Username") !== "")
            return api.memory.get("Username");
        return "";
    }

    property string pendingLauncherUser: ""
    property var profileGateAction: null

    function requestProfile(action) {
        pendingLauncherUser = "";
        if (api.memory.get("Multi User") === "Yes" && api.memory.has("profile_1")) {
            profileGateAction = action;
            profilePicker.open();
        } else {
            action();
        }
    }

    function restoreFocusAfterProfile() {
        if (gameDetailOpen)
            gameDetailScreen.forceActiveFocus();
        else if (softwareScreen.visible)
            softwareScreen.forceActiveFocus();
        else
            homeScreen.forceActiveFocus();
    }

    // Launch the current game from HomeBar (with Eden / Android Direct Boot guard)
    function launchGame(game) {
        if (root.isLaunching) {
            console.log("[skylineOS2] launchGame ignored - debounce active to prevent duplicate intent");
            return;
        }
        root.isLaunching = true;
        launchDebounceTimer.restart();

        registerLauncherUser();
        pushToStackTimer(game);

        api.memory.set('Last Collection', currentCollection);
        if (game != null)
            game.launch();
        else if (currentGame != null)
            currentGame.launch();
    }

    // Launch current game from SoftwareScreen (with Eden / Android Direct Boot guard)
    function launchSoftware() {
        if (root.isLaunching) {
            console.log("[skylineOS2] launchSoftware ignored - debounce active to prevent duplicate intent");
            return;
        }
        root.isLaunching = true;
        launchDebounceTimer.restart();

        registerLauncherUser();
        api.memory.set('Last Collection', currentCollection);
        if (softwareSearch !== "" && currentGame)
            currentGame.launch();
        else if (softwareList && softwareList[sortByIndex])
            softwareList[sortByIndex].currentGame(currentGameIndex).launch();
    }

    // Theme settings
    FontLoader {
        id: titleFont
        source: "assets/fonts/Nintendo_Switch_UI_Font.ttf"
    }

    property var themeLight: {
        return {
            main: "#EBEBEB",
            secondary: "#2D2D2D",
            accent: api.memory.has("Accent Light Mode") ? api.memory.get("Accent Light Mode") : "#10AEBE",
            highlight: "white",
            text: "#2C2C2C",
            button: "white",
            icon: "#7e7e7e",
            press: "#7Fc0f0f3"
        };
    }

    property var themeDark: {
        return {
            main: "#2D2D2D",
            secondary: "#EBEBEB",
            accent: api.memory.has("Accent Dark Mode") ? api.memory.get("Accent Dark Mode") : "#1d9bf3",
            highlight: "black",
            text: "white",
            button: "#515151",
            icon: "white",
            press: "#591d9bf3"
        };
    }

    property var theme: api.memory.get("Dark Mode") === "No" ? themeLight : themeDark

    // State settings
    states: [
        State {
            name: "homescreen"
            when: homeScreen.focus == true
        },
        State {
            name: "softwarescreen"
            when: softwareScreen.focus == true
        },
        State {
            name: "settingsscreen"
            when: settingsScreen.focus == true
        },
        State {
            name: "infoscreen"
            when: infoScreen.focus == true
        },
        State {
            name: "backlogscreen"
            when: backlogScreen.focus == true
        },
        State {
            name: "suspendscreen"
            when: suspendScreen.focus == true
        },
        State {
            name: "playgame"
        },
        State {
            name: "playsoftware"
        }
    ]

    property int currentScreenID: -3

    transitions: [
        Transition {
            from: "homescreen"
            to: "softwarescreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: softwareScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: softwareScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: "homescreen"
            to: "settingsscreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: settingsScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: settingsScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: "softwarescreen"
            to: "homescreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: softwareScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: softwareScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: "settingsscreen"
            to: "homescreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: settingsScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: settingsScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            to: "playgame"
            SequentialAnimation {
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PauseAnimation {
                    duration: 200
                }
                ScriptAction {
                    script: launchGame(currentGame)
                }
            }
        },
        Transition {
            to: "playsoftware"
            SequentialAnimation {
                PropertyAnimation {
                    target: softwareScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PauseAnimation {
                    duration: 200
                }
                ScriptAction {
                    script: launchSoftware()
                }
            }
        },
        Transition {
            from: "homescreen"
            to: "infoscreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: infoScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: infoScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: "infoscreen"
            to: "homescreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: infoScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: infoScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: "homescreen"
            to: "backlogscreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: backlogScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: backlogScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: "backlogscreen"
            to: "homescreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: backlogScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: backlogScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: "homescreen"
            to: "suspendscreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: suspendScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: suspendScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: "suspendscreen"
            to: "homescreen"
            SequentialAnimation {
                PropertyAnimation {
                    target: suspendScreen
                    property: "opacity"
                    to: 0
                    duration: 200
                }
                PropertyAction {
                    target: suspendScreen
                    property: "visible"
                    value: false
                }
                PropertyAction {
                    target: homeScreen
                    property: "visible"
                    value: true
                }
                PropertyAnimation {
                    target: homeScreen
                    property: "opacity"
                    to: 1
                    duration: 200
                }
            }
        },
        Transition {
            from: ""
            to: "homescreen"
            ParallelAnimation {
                NumberAnimation {
                    target: homeScreen
                    property: "scale"
                    from: 1.2
                    to: 1.0
                    duration: 200
                    easing.type: Easing.OutQuad
                }
                NumberAnimation {
                    target: homeScreen
                    property: "opacity"
                    from: 0
                    to: 1
                    duration: 200
                }
            }
        }
    ]

    // Background
    Rectangle {
        id: background
        anchors {
            left: parent.left
            right: parent.right
            top: parent.top
            bottom: parent.bottom
        }
        color: theme.main
    }

    //starting collection is set here
    //E' un casino tutto innestato, devi un attimo capire come fare la ricerca UNA VOLTA e non 10mila come sta facendo ora, per ottimizzare il tutto
    Component.onCompleted: {
        state: "homescreen";
        refreshSettings();
        popToStackTimer();
        for (let i = 0; i < api.allGames.count; i++)
            console.log(api.allGames.get(i).title);

        currentCollection = -1;
        api.memory.unset('Last Collection');
        homeSfx.play();
    }

    SecondScreenHome {
        id: secondScreenHome
    }

    // Home screen
    HomeScreen {
        id: homeScreen
        hiddenApps: root.hiddenApps
        focus: true
        anchors {
            left: parent.left
            right: parent.right
            top: parent.top
            bottom: parent.bottom
        }
    }

    SettingsScreen {
        id: settingsScreen
        opacity: 0
        visible: false
        anchors {
            left: parent.left
            leftMargin: screenmargin
            right: parent.right
            rightMargin: screenmargin
            top: parent.top
            bottom: helpBar.top
        }
    }

    InfoScreen {
        id: infoScreen
        opacity: 0
        visible: false
        anchors {
            left: parent.left
            leftMargin: screenmargin
            right: parent.right
            rightMargin: screenmargin
            top: parent.top
            bottom: helpBar.top
        }
    }

    BacklogScreen {
        id: backlogScreen
        opacity: 0
        visible: false
        anchors {
            left: parent.left
            leftMargin: screenmargin
            right: parent.right
            rightMargin: screenmargin
            top: parent.top
            bottom: helpBar.top
        }
    }

    SuspendScreen {
        id: suspendScreen
        opacity: 0
        visible: false
        anchors {
            left: parent.left
            leftMargin: screenmargin
            right: parent.right
            rightMargin: screenmargin
            top: parent.top
            bottom: helpBar.top
        }
    }

    // All Software screen
    SoftwareScreen {
        id: softwareScreen
        opacity: 0
        visible: false
        anchors {
            left: parent.left// leftMargin: screenmargin
            right: parent.right// rightMargin: screenmargin
            top: parent.top
            bottom: parent.bottom
        }
    }

    //Changes Sort Option
    function cycleSort() {
        selectSfx.play();
        if (sortByIndex < softwareList.length - 1)
            sortByIndex++;
        else
            sortByIndex = 0;
        api.memory.set('sortIndex', sortByIndex);
    }

    Rectangle {
        id: gameDetailDim
        anchors.fill: parent
        color: "black"
        opacity: gameDetailOpen ? 0.6 : 0
        visible: opacity > 0
        z: 99
        Behavior on opacity {
            NumberAnimation {
                duration: 250
            }
        }
    }

    GameDetailScreen {
        id: gameDetailScreen
        currentGame: currentGame
        z: 100

        x: gameDetailOpen ? 0 : detailOriginX
        y: gameDetailOpen ? 0 : detailOriginY
        width: gameDetailOpen ? screenwidth : detailOriginWidth
        height: gameDetailOpen ? screenheight : detailOriginHeight
        radius: gameDetailOpen ? 0 : vpx(24)
        opacity: gameDetailOpen ? 1 : 0
        visible: opacity > 0.01

        Behavior on x {
            NumberAnimation {
                duration: 320
                easing.type: Easing.OutCubic
            }
        }
        Behavior on y {
            NumberAnimation {
                duration: 320
                easing.type: Easing.OutCubic
            }
        }
        Behavior on width {
            NumberAnimation {
                duration: 320
                easing.type: Easing.OutCubic
            }
        }
        Behavior on height {
            NumberAnimation {
                duration: 320
                easing.type: Easing.OutCubic
            }
        }
        Behavior on radius {
            NumberAnimation {
                duration: 320
                easing.type: Easing.OutCubic
            }
        }
        Behavior on opacity {
            NumberAnimation {
                duration: 220
            }
        }
    }

    NewProfileScreen {
        id: newProfileScreen
    }

    SatelliteProfileScreen {
        id: satelliteProfileScreen
        onConfirmRequested: requestConfirm(title, subtitle, action, focusItem)
    }

    ProfilePicker {
        id: profilePicker
        onChosen: {
            pendingLauncherUser = name;
            var act = profileGateAction;
            profileGateAction = null;
            restoreFocusAfterProfile();
            if (act)
                act();
        }
        onCancelled: {
            profileGateAction = null;
            restoreFocusAfterProfile();
        }
    }

    // Help bar
    Item {
        id: helpBar
        anchors {
            left: parent.left
            leftMargin: screenmargin
            right: parent.right
            rightMargin: screenmargin
            bottom: parent.bottom
        }
        height: helpbarheight

        opacity: (homeScreen.expandedPanelOpen || gameDetailOpen || softwareScreen.focus || root.state === "suspendscreen") ? 0 : 1
        visible: opacity > 0
        Behavior on opacity {
            NumberAnimation {
                duration: 200
            }
        }

        Rectangle {

            anchors.fill: parent
            color: theme.main
            opacity: softwareScreen.focus ? 1 : 0
            Behavior on opacity {
                NumberAnimation {
                    duration: 200
                }
            }
        }

        Rectangle {
            anchors.left: parent.left
            anchors.right: parent.right
            height: 1
            opacity: homeScreen.focus ? 0 : 0.3
            color: theme.secondary
            Behavior on opacity {
                NumberAnimation {
                    duration: 200
                }
            }
        }

        ControllerHelp {
            id: controllerHelp
            width: parent.width
            height: parent.height
            anchors {
                bottom: parent.bottom
            }
            showBack: !homeScreen.focus
            showCollControls: softwareScreen.focus
            showFav: softwareScreen.focus || homeScreen.focus
            showDetails: homeScreen.focus || softwareScreen.focus
        }
    }

    Timer {
        id: launchRecoveryTimer
        interval: 3
        running: root.state === "playgame" || root.state === "playsoftware"
        repeat: false
        onTriggered: {
            if (root.state === "playgame") {
                homeScreen.opacity = 1;
                root.state = "homescreen";
            } else if (root.state === "playsoftware") {
                softwareScreen.opacity = 1;
                root.state = "softwarescreen";
            }
        }
    }

    SoundEffect {
        id: navSound
        source: "assets/audio/Klick.wav"
        volume: 1.0
    }

    SoundEffect {
        id: toSoftware
        source: "assets/audio/EnterBack.wav"
        volume: 1.0
    }

    SoundEffect {
        id: fillList
        source: "assets/audio/Icons.wav"
        volume: 1.0
    }

    SoundEffect {
        id: backSfx
        source: "assets/audio/Nock.wav"
        volume: 1.0
    }

    SoundEffect {
        id: launchSfx
        source: "assets/audio/PopupRunTitle.wav"
        volume: 1.0
    }

    SoundEffect {
        id: homeSfx
        source: "assets/audio/Home.wav"
        volume: 1.0
    }

    SoundEffect {
        id: turnOnSfx
        source: "assets/audio/Turn On.wav"
        volume: 1.0
    }

    SoundEffect {
        id: turnOffSfx
        source: "assets/audio/Turn Off.wav"
        volume: 1.0
    }

    SoundEffect {
        id: selectSfx
        source: "assets/audio/This One.wav"
        volume: 1.0
    }

    SoundEffect {
        id: settingsSfx
        source: "assets/audio/Settings.wav"
        volume: 1.0
    }

    SoundEffect {
        id: menuNavSfx
        source: "assets/audio/Tick.wav"
        volume: 1.0
    }

    SoundEffect {
        id: borderSfx
        source: "assets/audio/Border.wav"
        volume: 0.25
    }

    SoundEffect {
        id: storeSfx
        source: "assets/audio/store.wav"
        volume: 1.0
        onStatusChanged: console.log("SFX store status:", status, source)
        onPlayingChanged: console.log("SFX store playing:", playing)
    }

    SoundEffect {
        id: detailSfx
        source: "assets/audio/detail.wav"
        volume: 1.0
        onStatusChanged: console.log("SFX detail status:", status, source)
        onPlayingChanged: console.log("SFX detail playing:", playing)
    }

    SoundEffect {
        id: feedSfx
        source: "assets/audio/Dada 3.wav"
        volume: 1.0
    }

    SoundEffect {
        id: browserSfx
        source: "assets/audio/Browser.wav"
        volume: 1.0
    }

    SoundEffect {
        id: backlogSfx
        source: "assets/audio/Backlog.wav"
        volume: 1.0
    }

    SoundEffect {
        id: cloudSfx
        source: "assets/audio/Jig 0.wav"
        volume: 1.0
    }

    SoundEffect {
        id: albumSfx
        source: "assets/audio/Album.wav"
        volume: 1.0
    }

    SoundEffect {
        id: filesSfx
        source: "assets/audio/File.wav"
        volume: 1.0
    }

    SoundEffect {
        id: standbySfx
        source: "assets/audio/Standby.wav"
        volume: 1.0
    }

    SoundEffect {
        id: allSoftSfx
        source: "assets/audio/Allsf.wav"
        volume: 1.0
    }

    SoundEffect {
        id: userSfx
        source: "assets/audio/User.wav"
        volume: 1.0
    }

    SoundEffect {
        id: newUserSfx
        source: "assets/audio/NewUser.wav"
        volume: 1.0
    }
}
