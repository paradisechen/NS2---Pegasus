// skylineOS 2 — Master HighlightBorder.qml (Switch 2 Concentric Iridescent Border)
import QtQuick 2.8
import QtGraphicalEffects 1.12

Rectangle {
    id: hlBorder
    property bool selected: false
    property int borderwidth: (typeof idx !== "undefined" && idx == -3) ? vpx(8) : vpx(6)
    property int borderRadius: vpx(30)
    width: parent.width
    height: parent.height
    color: (typeof uiPalette !== "undefined" && uiPalette && uiPalette.borderPrimary) ? uiPalette.borderPrimary : theme.accent
    radius: borderRadius

    layer.enabled: enableDropShadows
    layer.effect: DropShadow {
        transparentBorder: true
        horizontalOffset: 0
        verticalOffset: 0
        color: "#4D000000"
        radius: 3.0
        samples: 6
        z: -2
    }

    opacity: selected ? 1 : 0
    Behavior on opacity {
        NumberAnimation {
            duration: 75
        }
    }

    Rectangle {
        width: parent.width - (borderwidth * 2)
        height: parent.height - (borderwidth * 2)
        radius: borderRadius
        anchors.centerIn: parent
        color: (typeof idx !== "undefined" && idx == -3) ? theme.button : theme.highlight
        opacity: 1
    }
}
